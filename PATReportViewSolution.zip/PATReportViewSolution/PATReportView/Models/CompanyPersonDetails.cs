﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyPersonDetails
    {
        public string Salutation { get; set; }
        public byte[] PersonPhoto { get; set; }
        public string CompanyReportedName { get; set; }
        public int Age { get; set; }
        public string FirstName { get; set; }
        public int DOBday { get; set; }
        public int DOBMonth { get; set; }
        public int DOBYear { get; set; }
        public string LastName { get; set; }
        public string EduQualification { get; set; }
        public string SocialNetwork { get; set; }
        public string SocialNetworkSiteName { get; set; }
        public string SocialSiteURL { get; set; }
        public string[] SourceURL { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }

        //For person Designation Details
      public  List<CompanyPersonDesignationDetails> lstDesig { get; set; }

        //For Person management Info Details
       public  List<CompanyPersonManagementInfo> lstManagementInfo { get; set; }
    }
}
