﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyPersonManagementInfo
    {
        public string EmailID { get; set; }
        public string[] SourceURL { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }
        public string Biography { get; set; }
        public string CompanyRelatedDesig { get; set; }
        public string Phone { get; set; }
        public int FromDateMonth { get; set; }
        public int FromDateYear { get; set; }
        public int ToDateMonth { get; set; }
        public int ToDateYear { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }

    }
}