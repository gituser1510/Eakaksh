﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models.Product
{
    public class ProductTaxonomies
    {
        public string IndicationNames { get; set; }
        public string ModeofAction { get; set; }
        public string ROA
        {
            get; set;
        }
        public string ATC { get; set; }
        public string MOA { get; set; }
        public string CreatedName { get; set; }
        public string CreatedDate { get; set; }
        public string LastUpdatedName { get; set; }
        public string LastUpdatedDate { get; set; }

    }
}