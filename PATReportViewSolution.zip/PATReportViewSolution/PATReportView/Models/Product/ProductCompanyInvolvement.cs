﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models.Product
{
    public class ProductCompanyInvolvement
    {
        public int? ProductIndCompInvolvementID { get; set; }
        public string CompanyName { get; set; }
        public string TherapeuticIndicationName { get; set; }
        public string PhaseName { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedDate { get; set; }
    }
    public class Companydetails
    {
        public string InvolvementStatus { get; set; }
        public string CompanyRole { get; set; }
        public string CompanyReportedIndication { get; set; }
        public string DealId { get; set; }
        public string PartneringOpportunit { get; set; }
        public string POFuturisticPhase { get; set; }
        public string PONotes { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string LineofTherapy { get; set; }
        public string Agreement { get; set; }
        public string POPartnershipType { get; set; }
        public string POUpdatedDate { get; set; }
        public string SourceURLs { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedDate { get; set; }


    }


    public class DosageDetails
    {
        public string DosageForm { get; set; }
        public string ROA { get; set; }
        public string Strength { get; set; }
        public string MarketingStatus { get; set; }
        public string DosageDeails { get; set; }
        public string[] SourceURL { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedDate { get; set; }
    }

    public class GeoIncludeDetails
    {
        public string GeoIncludedCountry { get; set; }
        public string Region { get; set; }
        public string Status { get; set; }
        public string ProductOtherName { get; set; }
        public string NameType { get; set; }
        public string[] SourceURL { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedDate { get; set; }

    }

    public class GeoExcludeDetails
    {
        public string GeoExcludedCountry { get; set; }
        public string Region { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedDate { get; set; }

    }
}