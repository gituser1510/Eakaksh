﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PATReportView.Models.Product
{
    public class ProductViewModel
    {
        #region Pharmacology
        public string Errormsg { get; set; }
        public string ScheduleDrug { get; set; }
        public int ProductID { get; set; }
        public string BlackBoxWarning { get; set; }
        public string Pharmadynamics { get; set; }
        public string Pharmacokinetics { get; set; }
        public string Toxicology { get; set; }
        public string AdverseEffects { get; set; }
        public string DrugInteractions { get; set; }
        public string ContraIndications { get; set; }
        public string PrescribingInformation { get; set; }
        public string ProductLabe { get; set; }
        public string ProductLabelLink { get; set; }
        public string AdditionalSponsoredWebsites { get; set; }
        public string ProductName { get; set; }
        public string ProductWebsite { get; set; }
        public string BlackBox { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }
        #endregion
        #region BasicInfo 
        public List<ProductBasicInfoViewModel> lstProductBasicInfo { get; set; }
        public List<SouceDetials> lstProductBasicSourceDetails { get; set; }
        public List<ChemicalBiologicalClassification> lstChemicalBiologicalClassification { get; set; }

        public List<TreeViewLocation> lsttreeCB { get; set; }

        public List<BasicIndicationDetails> lstBasicIndications { get; set; }

        #endregion

        #region Taxonomies       

        public List<ProductTaxonomies> lsttaxonomies { get; set; }

        #endregion

        #region PhaseandTrialDetails
        public List<PhaseandTrialDetails> lstPhaseandTrialDetails { get; set; }
        public List<Indications> lstIndications { get; set; }
        public List<Phase> lstphase { get; set; }
        public List<PhaseDetails> lstphaseDetails { get; set; }
        #endregion

        #region Milestones
        public List<Milestones> lstMilestones { get; set; }
        #endregion

        #region CompanyInvolvement
        public List<ProductCompanyInvolvement> lstCompanyInvolvement { get; set; }
        public List<Companydetails> lstCompanyDetails { get; set; }

        public List<DosageDetails> lstDosageDetails { get; set; }

        public List<GeoIncludeDetails> lstGeoIncluded { get; set; }
        #endregion
        public List<GeoExcludeDetails> lstGeoExcluded { get; set; }
    }
}