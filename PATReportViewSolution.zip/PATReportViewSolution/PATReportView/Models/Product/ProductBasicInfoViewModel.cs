﻿using AuthoringToolDataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models.Product
{
    public class ProductBasicInfoViewModel
    {
        public string Errormsg { get; set; }
        public int ProducID { get; set; }
        public string ProductName { get; set; }
        public string MoleculeTypeName { get; set; }
        public string ProductTypeName { get; set; }
        public string ProductCategoryName { get; set; }
        public string TreatmentTypeName { get; set; }
        public string ProductWebsite { get; set; }
        public string ActiveIngredientName { get; set; }
        public string ProductDescription { get; set; }
        public string Notes { get; set; }
        public string CreatedName { get; set; }
        public string CreatedDate { get; set; }
        public string LastUpdatedName { get; set; }
        public string LastUpdatedDate { get; set; }

    }
    public class SouceDetials
    {
        public string SourceLink { get; set; }
        public int SourceTypeID { get; set; }
    }

    public class BasicIndicationDetails
    {
        public string IndicationNames { get; set; }
        public string Taxonomies { get; set; }
        public string HighestPhaseNames { get; set; }
        public string CompanyInvolvedNames { get; set; }
    }
    public class ChemicalBiologicalClassification
    {
        public string Chemical_BiologicalClassfSeqNames { get; set; }

        public string ActiveIngredients { get; set; }
        public int Chemical_BiologicalClassfSeqId { get; set; }

        public List<TreeViewLocation> lsttreeCB { get; set; }
        public List<TreeViewLocation> GetLocations(string[] str)
        {

            List<TreeViewLocation> lstCmp = new List<TreeViewLocation>();

            TreeViewLocation objParent = null;
            int count = 0;
            Recursive(ref objParent, ref count, str);

            lstCmp.Add(objParent);

            return lstCmp;
        }
        public  int Recursive(ref TreeViewLocation parent, ref int count, string[] str)
        {
            if (parent == null)
                parent = new TreeViewLocation();
            TreeViewLocation chiled = new TreeViewLocation();
            parent.Name = str[count];
            count++;
            if (count < str.Length)
            {
                chiled.Name = str[count];
                parent.ChildLocations.Add(chiled);
                Recursive(ref chiled, ref count, str);
            }
            return 0;
        }
      
    }
    public class TreeViewLocation
    {
        public TreeViewLocation()
        {
            ChildLocations = new HashSet<TreeViewLocation>();
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<TreeViewLocation> ChildLocations { get; set; }
    }
}
