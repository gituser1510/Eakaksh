﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PATReportView.Models.Product
{
    public class Milestones
    {
       
        public string MilestoneDate { get; set; }
        public string EstimatedMilestoneStartDate { get; set; }
        public string EstimatedMilestoneEndDate { get; set; }
        public string MilestoneStatus { get; set; }
        public string MilestoneAchieveddate { get; set; }
        public string MilestoneGeography { get; set; }
        public string MilestoneClassCategory { get; set; }
        public string MilestoneHeadline { get; set; }
        public string MilestoneDetails { get; set; }
        public string CurrentPhaseName { get; set; }
        public string AsReportedStartDate { get; set; }
        public string AsReportedEndDate { get; set; }
        public string PDUFADate { get; set; }
        public string AsReportedAchievedDate { get; set; }
        public string MilestonePhase { get; set; }
        public string MilestoneBrief { get; set; }
        public string ClinicaltrialRegistryID { get; set; }
        public string NewsID { get; set; }
        public string SourceName { get; set; }
        public string[] SourceURLs { get; set; }
        public string LastUpdatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string ProductIDTechnologyIDDeviceID { get; set; }
        public string ProductNameTechnologyNameDeviceName { get; set; }
    }
}