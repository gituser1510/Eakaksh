﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models.Product
{
    public class PhaseandTrialDetails
    {
        //public int ProductIndicationID { get; set; }
        //public string TherapeuticIndicationName { get; set; }
        //public List<Indications> lstIndications { get; set; }
        public List<Phase> lstPhase { get; set; }
        public List<PhaseDetails> lstPhaseDetails { get; set; }
    }
    public class Indications
    {
        public int ProductIndicationID { get; set; }
        public string TherapeuticIndicationName { get; set; }
    }
    public class Phase
    {
        public string PhaseName { get; set; }
        public int PhaseNameID { get; set; }
        public string PhaseStatus { get; set; }
        public int PhaseStatusID { get; set; }
        public string InactiveReasonName { get; set; }
        public string PhaseStartDate { get; set; }
        public string PhaseEndDate { get; set; }
        public string TrialUpdatesCount { get; set; }
        public string Companys { get; set; }
        public string[] SourceURL { get; set; }
        public int ProductIndPhaseDetailsID { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }
    }
    public class PhaseDetails
    {
        public string TrialDate { get; set; }
        public string TrialDistinguisherName { get; set; }
        public string IsActive { get; set; }
        public string TrailDetails { get; set; }
        public string Summary { get; set; }
        public string[] SourceLinks { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }
    }
}