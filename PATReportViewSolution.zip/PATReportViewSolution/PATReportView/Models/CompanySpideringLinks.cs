﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanySpideringLinks
    {
        public string SpideringsecKey { get; set; }
        public string SectionKeywords { get; set; }
        public string SectionURL { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }

    }
}