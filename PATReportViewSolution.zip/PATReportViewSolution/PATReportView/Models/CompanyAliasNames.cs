﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyAliasNames
    {
        public string OtherName { get; set; }
        public string  NameType { get; set; }
        public Int32 FromDay { get; set; }
        public Int32 FromMonth { get; set; }
        public Int32 FromYear { get; set; }
        public Int32 ToDay { get; set; }
        public Int32 ToMonth { get; set; }
        public Int32 ToYear { get; set; }
        public string[] SourceURL { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }
    }
}