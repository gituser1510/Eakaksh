﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyOffices
    {
        public string OfficeName { get; set; }
        public string OfficeDetails { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Pincode { get; set; }
        public string Phone { get; set; }
        public string Extension { get; set; }
        public string Fax { get; set; }
        public bool IsRegulatoryCertified { get; set; }
        public string  FacilityTypeID { get; set; }
        public string  State { get; set; }
        public string  Country { get; set; }
        public bool IsActive { get; set; }
        public string City { get; set; }
        public string Email { get; set; }
        public string RegulatoryAuthority { get; set; }
        public string[] SourceURL { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
    }
}