﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyPersonDesignationDetails
    {
        public string Designation { get; set; }

        public string DeptSubCategory { get; set; }
        public string DesigSubCategory { get; set; }
        public string Department { get; set; }
        public bool IsActiveDesig { get; set; }
        public bool IsActiveDept { get; set; }
    }
}