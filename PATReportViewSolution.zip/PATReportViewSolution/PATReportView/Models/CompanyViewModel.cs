﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.IO;
using AuthoringToolTaxonomies;
using AuthoringToolDataAccess;

namespace PATReportView.Models
{
    public class CompanyViewModel
    {
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }
        public int CompanyID { get; set; }
        public bool IsPublic { get; set; }
        public string TickerSymbol { get; set; }
        public string InCorporationDateDay { get; set; }

        public string IPODate { get; set; }
        public string FiscalYearEnd { get; set; }
        public int CompanyEmployeeCount { get; set; }
        public string CompanyStatus { get; set; }
        public string CompanyType { get; set; }
        public string InactiveReason { get; set; }
        public Nullable<DateTime> InactiveDate { get; set; }
        public byte[] LogoUrl { get; set; }
        public string LogoPath { get; set; }
        public string CategoryKey { get; set; }
        public Nullable<DateTime> ActualInactiveDate { get; set; }
        public string Description { get; set; }
        public bool HasSubsidary { get; set; }
        public bool IsserviceProvider { get; set; }
        public bool HasPartneringOppurtunities { get; set; }
        public string[] SourceUrl { get; set; }
        public string LastUpdatedBy { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string Errormsg { get; set; }
        public string LastUpdatedDate { get; set; }

        //public List<AliasName> lstAliasName { get; set; }
        public List<object> lst { get; set; }

        //AliasNames
        public List<CompanyAliasNames> lstOtherNames { get; set; }

        //Social Networks 
        public List<CompanySocialNetworks> lstSocialNetworks { get; set; }

        //CompanyOffices
        public List<CompanyOffices> lstCompanyOffices { get; set; }

        //ShareInfo
        public List<CompanyShareInfo> lstCompanyShareInfo { get; set; }

        //Partnering Oppurtunities
        public List<CompanyPartneringoppurtunities> lstPartneringOppurtunities { get; set; }

        //Company Highlights
        public List<CompanyHighlights> lstcmpHighlights { get; set; }

        //Company SpideringLinks
        public List<CompanySpideringLinks> lstSpideringLinks { get; set; }
        //Company Documents
        public List<CompanyDocumentDetails> lstcmpDocument { get; set; }

        //Company SubsidaryInfo
        public List<CompanySubsidaryInfo> lstcmpSubsidaryInfo { get; set; }
        //Person Details
        public List<CompanyPersonLevelDetails> lstPersons { get; set; }

        //CompanyIndustry Hub
        public List<CompanyIndustry> lstCmpIndustry { get; set; }
        //Service Therapy
        public List<CompanyServiceTheraphy> lstServiceTheraphy { get; set; }
    }

    //This class contains properties which are used to bind Industry hub(Parent and child relation) in companyBasicInfo
    public class TreePath
    {
        public string fullPath { get; set; }
        public string treeIds { get; set; }
        public string isPrimary { get; set; }
    }

    //This class contains methods and properties which are used to bind Industry hub in companyBasicInfo
    public class CompanyIndustry
    {
        public string CompanyIndustryIsPrimary { get; set; }
        public string CompanyIndustryName { get; set; }


        public List<TreePath> CompanyIndustryDetails(int companyId)
        {
            string path = "";
            string trees = "";
            string primary = "";
            using (var context = new CompanyInfoContext())
            {
                List<TreePath> dynList = new List<TreePath>();
                var industryHubs = (from i in context.CompanyIndustryHubs.Where(x => x.CompanyID == companyId) select i).ToList();
                if (industryHubs.Count != 0)
                {
                    foreach (var item in industryHubs)
                    {
                        if (item.IndustryHubID != 0)
                        {
                            string parentfullpath = GetIndustryHubname(item.IndustryHubID);
                            path = parentfullpath.TrimEnd('/');
                            trees = Convert.ToString(item.IndustryHubID).TrimEnd('-');
                            primary = item.IsPrimary == true ? "Yes" : "No";
                        }
                        if (item.IndustryHubCategory1ID != 0)
                        {
                            string childFullpath = GetIndustryHubCategory1name(item.IndustryHubCategory1ID);
                            path = (path + "/" + childFullpath).TrimEnd('/'); ;
                            trees = (trees + "-" + Convert.ToString(item.IndustryHubCategory1ID)).TrimEnd('-');
                            primary = item.IsPrimary == true ? "Yes" : "No";
                        }
                        if (item.IndustryHubCategory2ID != 0)
                        {
                            string SubChildFullpath = GetIndustryHubCategory2name(item.IndustryHubCategory2ID);
                            path = (path + "/" + SubChildFullpath).TrimEnd('/'); ;
                            trees = (trees + "-" + Convert.ToString(item.IndustryHubCategory2ID)).TrimEnd('-');
                            primary = item.IsPrimary == true ? "Yes" : "No";
                        }
                        dynList.Add(new TreePath
                        {
                            fullPath = path,
                            treeIds = trees,
                            isPrimary = primary,
                        });
                    }

                }
                return dynList.ToList();
            }

        }

        public string GetIndustryHubname(int? hubID)
        {
            using (var context = new TaxonomiesContext())
            {
                string pathName = (from i in context.MasterIndustryHubs.Where(x => x.IndustryHubID == hubID) select i.IndustryHubName).SingleOrDefault();
                return pathName;
            }
        }
        public string GetIndustryHubCategory1name(int? hubCategory1ID)
        {
            using (var context = new TaxonomiesContext())
            {
                string pathName = (from i in context.MasterIndustryHubCategory1.Where(x => x.IndustryHubCategory1ID == hubCategory1ID) select i.CategoryName1).SingleOrDefault();
                return pathName;
            }
        }
        public string GetIndustryHubCategory2name(int? hubCategory2ID)
        {
            using (var context = new TaxonomiesContext())
            {
                string pathName = (from i in context.MasterIndustryHubCategory2.Where(x => x.IndustryHubCategory2ID == hubCategory2ID) select i.CategoryName2).SingleOrDefault();
                return pathName;
            }
        }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
    }

    //This class contains methods and properties which are used to bind service Therapy in companyBasicInfo
    public class CompanyServiceTheraphy
    {
        public string ServiceTheraphyArea { get; set; }


        public List<CompanyServiceTheraphy> ServiceTheraphy(int companyID)
        {
            using (var contxt = new CompanyInfoContext())
            {
                List<CompanyServiceTheraphy> lst = new List<CompanyServiceTheraphy>();
                var therapyAreas = contxt.spGetCompanyTherapyAreas(companyID).ToList();
                TaxonomiesContext taxocontext = new TaxonomiesContext();
                var therapyAreasCount = (from i in taxocontext.MasterListKeyValues.Where(x => x.ListKeyID == 6) select i).ToList();
                if (therapyAreas != null)
                {

                    foreach (var item in therapyAreas)
                    {
                        CompanyServiceTheraphy objservice = new CompanyServiceTheraphy();
                        var TheraphyName = (from theraphy in taxocontext.MasterListKeyValues
                                            where theraphy.ListKeyValuesID == item.TherapyAreaID
                                            select theraphy).SingleOrDefault();
                      objservice.ServiceTheraphyArea = TheraphyName.KeyValue;
                        lst.Add(objservice);
                    }
                }
                return lst;
            }
        }
    }

}