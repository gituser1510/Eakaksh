﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyPersonLevelDetails
    {
        public string PersonName { get; set; }
        public int PersonID { get; set; }
        public int CmpPersonManagementInfoID { get; set; }
        public string Department { get; set; }
        public string Designation { get; set; }
        public string DesigSubCategory { get; set; }
        public string DeptSubCategory { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedDate { get; set; }
    }
}