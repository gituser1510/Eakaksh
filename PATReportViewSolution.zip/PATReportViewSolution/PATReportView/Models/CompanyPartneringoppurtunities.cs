﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyPartneringoppurtunities
    {
        public string LicensingInfo { get; set; }
        public string PO_countryID { get; set; }
        public string PO_regionID { get; set; }
        public string TherapyArea { get; set; }
        public string OppurtunityType { get; set; }
        public string OppurtunitySubType { get; set; }
        public string MoreDetails { get; set; }
        public string ProductName { get; set; }
        public string TechnologyName { get; set; }
        public string ContactPersonName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string SourceName { get; set; }
        public string[] SourceURL { get; set; }
        public string  MergeAndAcquisition { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
    }
}