﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanySubsidaryInfo
    {
        public string SubsidaryCompanyName { get; set; }
        public string JointVentureCompanyName { get; set; }
        public int SubsidaryCompanyID { get; set; }
        public bool IsActive { get; set; }
        public int JointVentureCompanyID { get; set; }
        public string RelationshipType { get; set; }
        public string RelationshipStatus { get; set; }
        public int CountryID { get; set; }
        public int CompanyRelationEndDateDay { get; set; }
        public int CompanyRelationEndDateMonth { get; set; }
        public int CompanyRelationEndDateYear { get; set; }
        public int CompanyRelationStartDateDay { get; set; }
        public int CompanyRelationStartDateMonth { get; set; }
        public int CompanyRelationStartDateYear { get; set; }
        public int OwnershipPercent { get; set; }
        public int OwnerShipShares { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedDate { get; set; }

    }
}