﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyHighlights
    {
        public Int32 FinancialYear { get; set; }
        public string BusinessHighLights { get; set; }
        public string GeographicReach { get; set; }
        public string PartneringAlliances { get; set; }
        public string ReseachDevSpending { get; set; }
        public string SalesMarketing { get; set; }
        public string PatentsIPrights { get; set; }
        public string SourceName { get; set; }
        public string[] SourceURL { get; set; }
        public string LastActivityBy { get; set; }
        public string LastActivityDate { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
    }
}