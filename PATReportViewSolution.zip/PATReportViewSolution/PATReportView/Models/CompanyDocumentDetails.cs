﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyDocumentDetails
    {
        public string DocumentName { get; set; }
        public Byte[] DocumentFile { get; set; }
        public string DocumentDate { get; set; }
        public string DocumentCategory { get; set; }
        public string DocumentsourceURL { get; set; }
        public string DocumentFileName { get; set; }
        public string DocumentPhysicalPath { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedDate { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
    }
}