﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PATReportView.Models
{
    public class CompanyShareInfo
    {
        public string TickerSymbol { get; set; }
        public string StockExchange { get; set; }
        public Nullable<DateTime> SharePriceTradeDate { get; set; }
        public Nullable<DateTime> DelistDate { get; set; }
        public string SharePrice { get; set; }
        public string Country { get; set; }
        public string CurrencyName { get; set; }
        public string Region { get; set; }
        public string Notes { get; set; }
        public bool Isprimary { get; set; }
        public bool ExchangeIsActive { get; set; }
        public string ExchangeDescription { get; set; }
        public string ISOCodeCountry { get; set; }
        public string ISOCodeCurrency { get; set; }
        public string[] SourceURL { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastupdatedDate { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
    }
}