﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AuthoringToolDataAccess;
using AuthoringToolTaxonomies;
using System.Web.Mvc;
using PATReportView.Models;
using System.IO;
using System.Drawing;
using System.Text.RegularExpressions;

namespace PATReportView.Controllers
{
    public class CompanyViewController : Controller
    {
        // GET: CompanyView
        int _companyID;
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(CompanyViewController));
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Search(string term)
        {
            try
            {

                // CompanyInfoEntities cmp = new CompanyInfoEntities();
                using (var companyInfocntx = new CompanyInfoContext())
                {

                    var _cmpName = (from customer in companyInfocntx.CompanyInfoes
                                    where customer.CompanyName.StartsWith(term)
                                    select customer.CompanyName).Distinct().ToList();
                    List<string> lst = new List<string>();

                    foreach (var cmpname in _cmpName)
                    {
                        lst.Add(cmpname.ToString());

                    }
                    return Json(lst, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                throw ex;
            }

        }
        //For Downloading the File
        public ActionResult Download(string DocumentSourceURL, int ID)
        {
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var CompanyDocument = companyInfocntx.spGetCompanyDocumentsByCompID(ID).ToList();
                    var FilteredStream = CompanyDocument.Where(p => p.DocumentSourceURL == DocumentSourceURL).ToList();
                    var DocumentFile = (from f in FilteredStream select f.DocumentFile).SingleOrDefault();
                    var DocumentFileName = (from f in FilteredStream select f.DocumentFileName).SingleOrDefault();
                    return File(DocumentFile.ToArray(), Path.GetExtension(DocumentFileName), DocumentFileName);
                }
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                return View("error");
                throw ex;
            }
        }
        //Social Networks
        public List<CompanySocialNetworks> GetSocialNetworks(int id)
        {
            List<CompanySocialNetworks> lst = new List<CompanySocialNetworks>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {

                    var SocialNetworks = companyInfocntx.spGetCompanySocialNetworkSitesByCompID(id).ToList();
                    if (SocialNetworks != null)
                    {
                        foreach (var _socialNetworks in SocialNetworks)
                        {
                            CompanySocialNetworks ObjCmpsocial = new CompanySocialNetworks();
                            ObjCmpsocial.SocialNetworkName = _socialNetworks.SocialNetworkKeyName;
                            ObjCmpsocial.SocialNetworkURL = _socialNetworks.SocialNetworkURL;
                            ObjCmpsocial.LastUpdatedBy = _socialNetworks.LastUpdatedName;
                            ObjCmpsocial.CreatedBy = _socialNetworks.CreatedName;
                            if (Convert.ToDateTime(_socialNetworks.CreatedDate) != DateTime.MinValue)
                            {
                                ObjCmpsocial.CreatedDate = (Convert.ToDateTime(_socialNetworks.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                ObjCmpsocial.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_socialNetworks.LastUpdatedDate) != DateTime.MinValue)
                            {
                                ObjCmpsocial.LastUpdatedOn = (Convert.ToDateTime(_socialNetworks.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                ObjCmpsocial.LastUpdatedOn = "";
                            }
                            lst.Add(ObjCmpsocial);
                        }
                    }
                }               
                return lst;
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        //Management Contacts
        public List<CompanyPersonLevelDetails> GetPersonLevelDetails(int id)
        {
            List<CompanyPersonLevelDetails> lst = new List<CompanyPersonLevelDetails>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var personnew = companyInfocntx.spGetCompanyPersonContactsLevelDetailsByCompID(id, 0).ToList();
                    if (personnew != null)
                    {

                        foreach (var _personDetails in personnew)
                        {
                            CompanyPersonLevelDetails objPersonLevel = new CompanyPersonLevelDetails();
                            objPersonLevel.PersonName = _personDetails.CompanyReportedName;
                            objPersonLevel.PersonID = Convert.ToInt32(_personDetails.CompanyPersonContactsID);
                            objPersonLevel.Department = _personDetails.DepartmentName;
                            objPersonLevel.Designation = _personDetails.DesignationName;
                            objPersonLevel.CmpPersonManagementInfoID = Convert.ToInt32(_personDetails.CompanyPersonManagementInfoID);
                            objPersonLevel.DeptSubCategory = _personDetails.DeptSubCategoryName;
                            objPersonLevel.DesigSubCategory = _personDetails.DesgSubCategoryName;
                            objPersonLevel.CreatedBy = _personDetails.CreatedName;
                            if (Convert.ToDateTime(_personDetails.CreatedDate) != DateTime.MinValue)
                            {
                                objPersonLevel.CreatedDate = (Convert.ToDateTime(_personDetails.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objPersonLevel.CreatedDate = "";
                            }
                            lst.Add(objPersonLevel);

                        }
                    }
                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        //Subsidary Information
        public List<CompanySubsidaryInfo> GetSubsidaryInfoDetails(int id)
        {

            List<CompanySubsidaryInfo> lst = new List<CompanySubsidaryInfo>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var CompanySubsidaryInformation = companyInfocntx.spGetCompanySubsidiaryInformationByCompID(id, 0).ToList();
                    if (CompanySubsidaryInformation != null)
                    {

                        foreach (var _cmpSubsidary in CompanySubsidaryInformation)
                        {
                            CompanySubsidaryInfo objSubsidary = new CompanySubsidaryInfo();
                            objSubsidary.CompanyRelationEndDateDay = Convert.ToInt32(_cmpSubsidary.CompanyRelationEnd_Day);
                            objSubsidary.CompanyRelationEndDateMonth = Convert.ToInt32(_cmpSubsidary.CompanyRelationEnd_Month);
                            objSubsidary.CompanyRelationEndDateYear = Convert.ToInt32(_cmpSubsidary.CompanyRelationEnd_Year);
                            objSubsidary.CompanyRelationStartDateDay = Convert.ToInt32(_cmpSubsidary.CompanyRelationStart_Day);
                            objSubsidary.CompanyRelationStartDateMonth = Convert.ToInt32(_cmpSubsidary.CompanyRelationStart_Month);
                            objSubsidary.CompanyRelationStartDateYear = Convert.ToInt32(_cmpSubsidary.CompanyRelationStart_Year);
                            objSubsidary.RelationshipStatus = _cmpSubsidary.RelationshipStatus;
                            objSubsidary.RelationshipType = _cmpSubsidary.RelationshipType;
                            objSubsidary.SubsidaryCompanyName = _cmpSubsidary.SubsidiaryName;
                            objSubsidary.SubsidaryCompanyID = Convert.ToInt32(_cmpSubsidary.SubsidiaryID);
                            objSubsidary.OwnershipPercent = Convert.ToInt32(_cmpSubsidary.OwnershipPercentage);
                            objSubsidary.OwnerShipShares = Convert.ToInt32(_cmpSubsidary.OwnershipShares);
                            objSubsidary.JointVentureCompanyID = Convert.ToInt32(_cmpSubsidary.JointVentureCompanyId);
                            objSubsidary.JointVentureCompanyName = _cmpSubsidary.JointVentureCompany;
                            //  objSubsidary.IsActive = Convert.ToBoolean(_cmpSubsidary.PSType);
                            objSubsidary.CreatedBy = _cmpSubsidary.CreatedName;
                            objSubsidary.UpdatedBy = _cmpSubsidary.LastUpdatedName;
                            if (Convert.ToDateTime(_cmpSubsidary.CreatedDate) != DateTime.MinValue)
                            {
                                objSubsidary.CreatedDate = (Convert.ToDateTime(_cmpSubsidary.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objSubsidary.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_cmpSubsidary.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objSubsidary.UpdatedDate = (Convert.ToDateTime(_cmpSubsidary.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objSubsidary.UpdatedDate = "";
                            }


                            // objSubsidary.CountryID=Convert.ToInt32(_cmpSubsidary.)
                            lst.Add(objSubsidary);


                        }
                    }

                }
                return lst;
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        //Company Offices
        public List<CompanyOffices> GetCompanyOffices(int id)
        {

            List<CompanyOffices> lst = new List<CompanyOffices>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var CompanyOffice = companyInfocntx.spGetCompanyOfficesByCompID(id).ToList();
                    if (CompanyOffice != null)
                    {

                        foreach (var _companyOffices in CompanyOffice)
                        {
                            CompanyOffices objCmpofc = new CompanyOffices();
                            objCmpofc.AddressLine1 = _companyOffices.AddressLine1;
                            objCmpofc.AddressLine1 = _companyOffices.AddressLine2;
                            objCmpofc.AddressLine3 = _companyOffices.AddressLine3;
                            objCmpofc.City = _companyOffices.City;
                            objCmpofc.Country = _companyOffices.Country;
                            objCmpofc.Email = _companyOffices.Email;
                            objCmpofc.Extension = _companyOffices.Extension;
                            objCmpofc.FacilityTypeID = _companyOffices.FacilityTypeKeyName;
                            objCmpofc.Fax = _companyOffices.Fax;
                            objCmpofc.IsActive = Convert.ToBoolean(_companyOffices.IsActive);
                            objCmpofc.IsRegulatoryCertified = Convert.ToBoolean(_companyOffices.IsRegulatoryCertified);
                            objCmpofc.LastUpdatedBy = _companyOffices.LastUpdatedName;
                            DateTime? dt = Convert.ToBoolean(Convert.ToDateTime(_companyOffices.LastUpdatedDate) == DateTime.MinValue) ? _companyOffices.LastUpdatedDate = null : Convert.ToDateTime(_companyOffices.LastUpdatedDate);

                            // objCmpofc.LastUpdatedDate = Convert.ToBoolean(Convert.ToDateTime(_companyOffices.LastUpdatedDate) == DateTime.MinValue) ? _companyOffices.LastUpdatedDate = null : Convert.ToDateTime(_companyOffices.LastUpdatedDate);
                            objCmpofc.OfficeDetails = _companyOffices.OfficeDetails;
                            objCmpofc.OfficeName = _companyOffices.CompanyName;
                            objCmpofc.Phone = _companyOffices.Phone;
                            objCmpofc.Pincode = _companyOffices.Pincode;
                            objCmpofc.RegulatoryAuthority = _companyOffices.RegulatoryAurhority;
                            objCmpofc.CreatedBy = _companyOffices.CreatedName;
                            if (Convert.ToDateTime(_companyOffices.CreatedDate) != DateTime.MinValue)
                            {
                                objCmpofc.CreatedDate = (Convert.ToDateTime(_companyOffices.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objCmpofc.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_companyOffices.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objCmpofc.LastUpdatedDate = (Convert.ToDateTime(_companyOffices.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objCmpofc.LastUpdatedDate = "";
                            }
                            //converting comma seperated sourceURL's into array
                            string cmpofcsource = _companyOffices.SourceURL;
                            if (cmpofcsource != null)
                            {
                                objCmpofc.SourceURL = cmpofcsource.Split(',');
                            }

                            objCmpofc.State = _companyOffices.State;
                            lst.Add(objCmpofc);
                        }
                    }
                }
                return lst;
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        //Company Document Details
        public List<CompanyDocumentDetails> GetDocumentDetails(int id)
        {

            List<CompanyDocumentDetails> lst = new List<CompanyDocumentDetails>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var CompanyDocument = companyInfocntx.spGetCompanyDocumentsByCompID(id).ToList();
                    if (CompanyDocument != null)
                    {

                        foreach (var _cmpDocument in CompanyDocument)
                        {
                            CompanyDocumentDetails objCmpDocument = new CompanyDocumentDetails();
                            objCmpDocument.DocumentCategory = _cmpDocument.DocumentCategoryName;
                            objCmpDocument.DocumentDate = _cmpDocument.DocumentDate;
                            objCmpDocument.DocumentFileName = _cmpDocument.DocumentFileName;
                            objCmpDocument.DocumentPhysicalPath = _cmpDocument.DocumentPhysicalPath;
                            objCmpDocument.DocumentsourceURL = _cmpDocument.DocumentSourceURL;
                            objCmpDocument.DocumentName = _cmpDocument.DocumentName;
                            objCmpDocument.LastUpdatedBy = _cmpDocument.LastUpdatedName;
                            objCmpDocument.CreatedBy = _cmpDocument.CreatedName;

                            if (Convert.ToDateTime(_cmpDocument.CreatedDate) != DateTime.MinValue)
                            {
                                objCmpDocument.CreatedDate = (Convert.ToDateTime(_cmpDocument.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objCmpDocument.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_cmpDocument.LastUpdateDate) != DateTime.MinValue)
                            {
                                objCmpDocument.LastUpdatedDate = (Convert.ToDateTime(_cmpDocument.LastUpdateDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objCmpDocument.LastUpdatedDate = "";
                            }
                            MemoryStream msn = new MemoryStream((byte[])(_cmpDocument.DocumentFile));
                            objCmpDocument.DocumentFile = msn.ToArray();
                            lst.Add(objCmpDocument);
                        }
                    }
                }
                return lst;
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        //Share Info
        public List<CompanyShareInfo> GetShareInfo(int id)
        {

            List<CompanyShareInfo> lst = new List<CompanyShareInfo>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var ShareInfo = companyInfocntx.spGetCompanyShareInformationByCompID(id).ToList();
                    if (ShareInfo != null)
                    {

                        foreach (var _cmpShareInf in ShareInfo)
                        {
                            CompanyShareInfo objCmpShareInfo = new CompanyShareInfo();
                            objCmpShareInfo.Country = _cmpShareInf.Country;

                            if (objCmpShareInfo.Country != null)
                            {
                                TaxonomiesContext taxoContext = new TaxonomiesContext();
                                var CountrySpecificDetails = (from country in taxoContext.MasterCountries
                                                              join region in taxoContext.MasterRegions on country.RegionID equals region.RegionID
                                                              where country.Country == objCmpShareInfo.Country
                                                              select new { country.CurrencyName, country.ISO_Code_Country_, country.ISO_Code_Currency_, region.RegionName }).SingleOrDefault();
                                objCmpShareInfo.Region = CountrySpecificDetails.RegionName;
                                objCmpShareInfo.ISOCodeCountry = CountrySpecificDetails.ISO_Code_Country_;
                                objCmpShareInfo.ISOCodeCurrency = CountrySpecificDetails.ISO_Code_Currency_;
                                objCmpShareInfo.CurrencyName = CountrySpecificDetails.CurrencyName;
                            }
                            objCmpShareInfo.DelistDate = Convert.ToBoolean(Convert.ToDateTime(_cmpShareInf.DelistDate) == DateTime.MinValue) ? _cmpShareInf.DelistDate = null : Convert.ToDateTime(_cmpShareInf.DelistDate);
                            objCmpShareInfo.StockExchange = _cmpShareInf.StockExchangeName;
                            objCmpShareInfo.ExchangeDescription = _cmpShareInf.ExchangeDescription;
                            objCmpShareInfo.ExchangeIsActive = Convert.ToBoolean(_cmpShareInf.ExchangeIsActive);
                            objCmpShareInfo.TickerSymbol = _cmpShareInf.TickerSymbol;
                            //converting comma seperated sourceURL's into array
                            string cmpsharesource = _cmpShareInf.SourceURL;
                            if (cmpsharesource != null)
                            {
                                objCmpShareInfo.SourceURL = cmpsharesource.Split(',');
                            }


                            objCmpShareInfo.LastUpdatedBy = _cmpShareInf.LastUpdatedName;

                            objCmpShareInfo.SharePrice = Convert.ToString(_cmpShareInf.SharePrice);
                            objCmpShareInfo.SharePriceTradeDate = Convert.ToBoolean(Convert.ToDateTime(_cmpShareInf.SharePriceTradeDate) == DateTime.MinValue) ? _cmpShareInf.SharePriceTradeDate = null : Convert.ToDateTime(_cmpShareInf.SharePriceTradeDate);
                            objCmpShareInfo.StockExchange = _cmpShareInf.StockExchangeName;
                            objCmpShareInfo.Notes = _cmpShareInf.Notes;
                            objCmpShareInfo.CreatedBy = _cmpShareInf.CreatedName;
                            if (Convert.ToDateTime(_cmpShareInf.CreatedDate) != DateTime.MinValue)
                            {
                                objCmpShareInfo.CreatedDate = (Convert.ToDateTime(_cmpShareInf.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objCmpShareInfo.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_cmpShareInf.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objCmpShareInfo.LastupdatedDate = (Convert.ToDateTime(_cmpShareInf.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objCmpShareInfo.LastupdatedDate = "";
                            }
                            objCmpShareInfo.Isprimary = Convert.ToBoolean(_cmpShareInf.IsPrimary);
                            lst.Add(objCmpShareInfo);
                        }
                    }

                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        //Partnering Opportunities
        public List<CompanyPartneringoppurtunities> GetPartneringoppurtunities(int id)
        {

            List<CompanyPartneringoppurtunities> lst = new List<CompanyPartneringoppurtunities>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var partneringOppurtunities = companyInfocntx.spGetCompanyPartneringOpportunitiesByCompID(id, 0).ToList();
                    if (partneringOppurtunities != null)
                    {

                        foreach (var _cmpPartnering in partneringOppurtunities)
                        {
                            CompanyPartneringoppurtunities objPartnering = new CompanyPartneringoppurtunities();
                            if (_cmpPartnering.TherapyArea != "-Select-")
                            {
                                objPartnering.TherapyArea = _cmpPartnering.TherapyArea;
                            }
                            else
                            {
                                objPartnering.TherapyArea = "";
                            }
                            //getting country and Region Names based on ID's 
                            TaxonomiesContext taxocontext = new TaxonomiesContext();
                            if (_cmpPartnering.PO_CountryID != 0)
                            {
                                objPartnering.PO_countryID = (from country in taxocontext.MasterCountries
                                                              where country.CountryID == _cmpPartnering.PO_CountryID
                                                              select country.Country).SingleOrDefault();
                            }
                            else
                            {
                                objPartnering.PO_countryID = "";
                            }
                            if (_cmpPartnering.PO_RegionID != 0)
                            {
                                objPartnering.PO_regionID = (from region in taxocontext.MasterRegions
                                                             where region.RegionID == _cmpPartnering.PO_RegionID
                                                             select region.RegionName).SingleOrDefault();
                            }
                            else
                            {
                                objPartnering.PO_regionID = "";
                            }
                            //converting comma seperated sourceURL's into array
                            string sourceurl = _cmpPartnering.SourceURL;
                            if (sourceurl != null)
                            {
                                objPartnering.SourceURL = sourceurl.Split(',');
                            }
                            objPartnering.OppurtunityType = _cmpPartnering.OpportunityTypeName;
                            objPartnering.OppurtunitySubType = _cmpPartnering.OpportunitySubTypeName;
                            objPartnering.LastUpdatedBy = _cmpPartnering.LastUpdatedName;

                            objPartnering.ProductName = _cmpPartnering.ProductName;
                            objPartnering.Email = _cmpPartnering.EmailID;
                            objPartnering.Phone = _cmpPartnering.Phone;
                            objPartnering.SourceName = _cmpPartnering.SourceName;
                            objPartnering.MoreDetails = _cmpPartnering.MoreDetails;
                            objPartnering.ContactPersonName = _cmpPartnering.PersonName;
                            objPartnering.MergeAndAcquisition = _cmpPartnering.MergerOrAcquisition == "-Select-" ? "NA" : _cmpPartnering.MergerOrAcquisition;
                            if (_cmpPartnering.CompanyPersonContactsID != 0)
                            {
                                objPartnering.ContactPersonName = (from personcontacts in companyInfocntx.CompanyPersonContacts
                                                                   where personcontacts.CompanyPersonContactsID == _cmpPartnering.CompanyPersonContactsID
                                                                   select personcontacts.CompanyReportedName).SingleOrDefault();

                            }
                            objPartnering.TechnologyName = _cmpPartnering.TechnologyName;
                            objPartnering.LicensingInfo = _cmpPartnering.LicensingInformation;
                            objPartnering.CreatedBy = _cmpPartnering.CreatedName;
                            if (Convert.ToDateTime(_cmpPartnering.CreatedDate) != DateTime.MinValue)
                            {
                                objPartnering.CreatedDate = (Convert.ToDateTime(_cmpPartnering.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objPartnering.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_cmpPartnering.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objPartnering.LastUpdatedDate = (Convert.ToDateTime(_cmpPartnering.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objPartnering.LastUpdatedDate = "";
                            }

                            lst.Add(objPartnering);

                        }
                    }

                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        //Company Highlights
        public List<CompanyHighlights> GetHighlights(int id)
        {

            List<CompanyHighlights> lst = new List<CompanyHighlights>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var CompanyHighlights = companyInfocntx.spGetCompanyHighlightsByCompID(id).ToList();
                    if (CompanyHighlights != null)
                    {

                        foreach (var _cmpHighlights in CompanyHighlights)
                        {
                            CompanyHighlights objcmpHighlights = new CompanyHighlights();
                            objcmpHighlights.BusinessHighLights = _cmpHighlights.BusinessOperations;
                            objcmpHighlights.PartneringAlliances = _cmpHighlights.Partnering_Alliances;
                            objcmpHighlights.FinancialYear = Convert.ToInt32(_cmpHighlights.FinancialYear);
                            objcmpHighlights.ReseachDevSpending = _cmpHighlights.RnDSpending;
                            objcmpHighlights.LastActivityBy = _cmpHighlights.LastUpdatedName;
                            objcmpHighlights.SalesMarketing = _cmpHighlights.SalesMarketing;
                            objcmpHighlights.SourceName = _cmpHighlights.SourceNames;
                            //converting comma seperated sourceURL's into array
                            string cmpHighlightssource = _cmpHighlights.SourceURL;
                            if (cmpHighlightssource != null)
                            {
                                objcmpHighlights.SourceURL = cmpHighlightssource.Split(',');
                            }

                            objcmpHighlights.PatentsIPrights = _cmpHighlights.Patents_OtherIPRights;
                            objcmpHighlights.GeographicReach = _cmpHighlights.GeographicReach;
                            objcmpHighlights.CreatedBy = _cmpHighlights.CreatedName;
                            if (Convert.ToDateTime(_cmpHighlights.CreatedDate) != DateTime.MinValue)
                            {
                                objcmpHighlights.CreatedDate = (Convert.ToDateTime(_cmpHighlights.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objcmpHighlights.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_cmpHighlights.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objcmpHighlights.LastActivityDate = (Convert.ToDateTime(_cmpHighlights.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objcmpHighlights.LastActivityDate = "";
                            }
                            lst.Add(objcmpHighlights);
                        }
                    }
                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        //Spidering Links
        public List<CompanySpideringLinks> GetSpideringLinks(int id)
        {

            List<CompanySpideringLinks> lst = new List<CompanySpideringLinks>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var CmpSpideringLinks = companyInfocntx.spGetCompanySpideringLinksByCompID(id).ToList();
                    if (CmpSpideringLinks != null)
                    {

                        foreach (var _cmpSpideringLinks in CmpSpideringLinks)
                        {
                            CompanySpideringLinks objSpideringLinks = new CompanySpideringLinks();
                            objSpideringLinks.LastUpdatedBy = _cmpSpideringLinks.LastUpdatedName;
                            objSpideringLinks.SectionKeywords = _cmpSpideringLinks.SectionKeyWords;
                            objSpideringLinks.SectionURL = _cmpSpideringLinks.SectionURL;
                            objSpideringLinks.SpideringsecKey = _cmpSpideringLinks.SpideringSectionKeyName;
                            objSpideringLinks.CreatedBy = _cmpSpideringLinks.CreatedName;
                            if (Convert.ToDateTime(_cmpSpideringLinks.CreatedDate) != DateTime.MinValue)
                            {
                                objSpideringLinks.CreatedDate = (Convert.ToDateTime(_cmpSpideringLinks.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objSpideringLinks.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_cmpSpideringLinks.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objSpideringLinks.LastUpdatedDate = (Convert.ToDateTime(_cmpSpideringLinks.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objSpideringLinks.LastUpdatedDate = "";
                            }
                            lst.Add(objSpideringLinks);

                        }

                    }
                }
                return lst;
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        //Alias Names
        public List<CompanyAliasNames> GetAliasNames(int id)
        {

            List<CompanyAliasNames> lst = new List<CompanyAliasNames>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var otherNameData = companyInfocntx.spGetCompanyOtherNamesByCompID(id).ToList();
                    if (otherNameData != null)
                    {

                        foreach (var _aliasNames in otherNameData)
                        {
                            CompanyAliasNames objAliasNames = new CompanyAliasNames();
                            objAliasNames.OtherName = _aliasNames.OtherName;
                            objAliasNames.NameType = _aliasNames.NameType;
                            objAliasNames.FromDay = Convert.ToInt32(_aliasNames.FromDateDay);
                            objAliasNames.FromMonth = Convert.ToInt32(_aliasNames.FromDateMonth);
                            objAliasNames.FromYear = Convert.ToInt32(_aliasNames.FromDateYear);
                            objAliasNames.ToDay = Convert.ToInt32(_aliasNames.ToDateDay);
                            objAliasNames.ToMonth = Convert.ToInt32(_aliasNames.ToDateMonth);
                            objAliasNames.ToYear = Convert.ToInt32(_aliasNames.ToDateYear);
                            //converting comma seperated sourceURL's into array
                            string url = _aliasNames.SourceURL;
                            if (url != null)
                            {
                                objAliasNames.SourceURL = url.Split(',');
                            }
                            objAliasNames.LastUpdatedBy = _aliasNames.LastUpdatedName;
                            // objAliasNames.LastUpdatedDate = Convert.ToBoolean(Convert.ToDateTime(_aliasNames.LastUpdatedDate) == DateTime.MinValue) ? _aliasNames.LastUpdatedDate = null : Convert.ToDateTime(_aliasNames.LastUpdatedDate);
                            objAliasNames.CreatedBy = _aliasNames.CreatedName;
                            if (Convert.ToDateTime(_aliasNames.CreatedDate) != DateTime.MinValue)
                            {
                                objAliasNames.CreatedDate = (Convert.ToDateTime(_aliasNames.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objAliasNames.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_aliasNames.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objAliasNames.LastUpdatedDate = (Convert.ToDateTime(_aliasNames.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objAliasNames.LastUpdatedDate = "";
                            }
                            lst.Add(objAliasNames);
                        }
                    }
                }
                return lst;
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        //Company Basic Details
        public ActionResult Company(string id)
        {
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    Regex r = new Regex("^[0-9]*$");
                    CompanyViewModel cmpView = new CompanyViewModel();
                    if (id != null && id != "")
                    {

                        if (r.IsMatch(id))
                        {
                            _companyID = Convert.ToInt32(id);
                        }
                        else
                        {
                            var ID = (from cmpInfo in companyInfocntx.CompanyInfoes
                                      where cmpInfo.CompanyName == id
                                      select cmpInfo.CompanyID).SingleOrDefault();
                            _companyID = ID;

                        }
                        if (_companyID != 0)
                        {
                            spGetCompanyInfoByCompID_Result companyInfoDetails = companyInfocntx.spGetCompanyInfoByCompID(_companyID).SingleOrDefault();

                            //To show LogoImage 
                            var companyLogo = (from i in companyInfocntx.CompanyLogoImages.Where(x => x.CompanyID == _companyID && x.IsActive == true) select i).SingleOrDefault();
                            if (companyLogo != null)
                            {
                                MemoryStream ms = new MemoryStream((byte[])companyLogo.CompanyLogoImage1);
                                cmpView.LogoUrl = ms.ToArray();
                            }

                            if (companyInfoDetails != null)
                            {
                                cmpView.CompanyName = companyInfoDetails.CompanyName;
                                cmpView.CompanyID = companyInfoDetails.CompanyID;
                                cmpView.FiscalYearEnd = companyInfoDetails.FiscalYearEnd;
                                cmpView.IsPublic = Convert.ToBoolean(companyInfoDetails.IsPublic);
                                cmpView.TickerSymbol = companyInfoDetails.TickerSymbol;
                                cmpView.CompanyEmployeeCount = Convert.ToInt32(companyInfoDetails.CompanyEmployeeCount);
                                cmpView.IsserviceProvider = Convert.ToBoolean(companyInfoDetails.IsServiceProvider);
                                cmpView.ActualInactiveDate = Convert.ToBoolean(Convert.ToDateTime(companyInfoDetails.ActualInactiveDate) == DateTime.MinValue) ? companyInfoDetails.ActualInactiveDate = null : Convert.ToDateTime(companyInfoDetails.ActualInactiveDate);
                                cmpView.InactiveReason = companyInfoDetails.InActiveReasonKeyName;
                                cmpView.LogoPath = companyInfoDetails.LogoURL;
                                cmpView.CategoryKey = companyInfoDetails.CategoryKeyName;
                                cmpView.CompanyType = companyInfoDetails.CompanyTypeKeyName;
                                cmpView.CompanyStatus = companyInfoDetails.CompanyStatusKeyName;
                                cmpView.InactiveDate = Convert.ToBoolean(Convert.ToDateTime(companyInfoDetails.InActiveDate) == DateTime.MinValue) ? companyInfoDetails.InActiveDate = null : Convert.ToDateTime(companyInfoDetails.InActiveDate);
                                cmpView.LastUpdatedBy = companyInfoDetails.LastUpdatedName;
                                cmpView.CreatedBy = companyInfoDetails.CreatedName;
                                //   cmpView.LastUpdatedDate = Convert.ToBoolean(Convert.ToDateTime(companyInfoDetails.LastUpdatedDate) == DateTime.MinValue) ? companyInfoDetails.LastUpdatedDate = null : Convert.ToDateTime(companyInfoDetails.LastUpdatedDate);
                                if (Convert.ToDateTime(companyInfoDetails.LastUpdatedDate) != DateTime.MinValue)
                                {
                                    cmpView.LastUpdatedDate = (Convert.ToDateTime(companyInfoDetails.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                                }
                                else
                                {
                                    cmpView.LastUpdatedDate = "";
                                }
                                if (Convert.ToDateTime(companyInfoDetails.CreatedDate) != DateTime.MinValue)
                                {
                                    cmpView.CreatedDate = (Convert.ToDateTime(companyInfoDetails.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                                }
                                else
                                {
                                    cmpView.CreatedDate = "";
                                }
                                cmpView.HasPartneringOppurtunities = Convert.ToBoolean(companyInfoDetails.HasPartneringOpportunities);
                                cmpView.HasSubsidary = Convert.ToBoolean(companyInfoDetails.HasSubsidary);
                                cmpView.Description = companyInfoDetails.Description;

                                if (!((companyInfoDetails.IPO_DateDay == 0 || companyInfoDetails.IPO_DateDay == null) && (companyInfoDetails.IPO_DateMonth == 0 || companyInfoDetails.IPO_DateMonth == null) && (companyInfoDetails.IPO_DateYear == 0 || companyInfoDetails.IPO_DateYear == null)))
                                {
                                    cmpView.IPODate = (((companyInfoDetails.IPO_DateDay) == 0 ? "--" : Convert.ToString(companyInfoDetails.IPO_DateDay)) + "/" + (companyInfoDetails.IPO_DateMonth == 0 ? "--" : Convert.ToString(companyInfoDetails.IPO_DateMonth)) + "/" + (companyInfoDetails.IPO_DateYear == 0 ? "--" : Convert.ToString(companyInfoDetails.IPO_DateYear)));
                                }
                                else
                                {
                                    cmpView.IPODate = "NA";
                                }
                                //converting comma seperated sourceURL's into array
                                string source = companyInfoDetails.SourceURL;
                                if (source != null)
                                {
                                    cmpView.SourceUrl = source.Split(',');
                                }

                                if (!((companyInfoDetails.InCorporationDateDay == 0 || companyInfoDetails.InCorporationDateDay == null) && (companyInfoDetails.InCorporationDateMonth == 0 || companyInfoDetails.InCorporationDateMonth == null) && (companyInfoDetails.InCorporationDateYear == 0 || companyInfoDetails.InCorporationDateYear == null)))
                                {
                                    cmpView.InCorporationDateDay = (((companyInfoDetails.InCorporationDateDay) == 0 ? "--" : Convert.ToString(companyInfoDetails.InCorporationDateDay)) + "/" + (companyInfoDetails.InCorporationDateMonth == 0 ? "--" : Convert.ToString(companyInfoDetails.InCorporationDateMonth)) + "/" + (companyInfoDetails.InCorporationDateYear == 0 ? "--" : Convert.ToString(companyInfoDetails.InCorporationDateYear)));
                                }
                                else
                                {
                                    cmpView.InCorporationDateDay = "NA";
                                }
                                CompanyServiceTheraphy objTheraphy = new CompanyServiceTheraphy();
                                var ServiceTheraphyName = objTheraphy.ServiceTheraphy(_companyID);
                                if (ServiceTheraphyName != null)
                                {
                                    cmpView.lstServiceTheraphy = new List<CompanyServiceTheraphy>();
                                    foreach (var theraphy in ServiceTheraphyName)
                                    {
                                        CompanyServiceTheraphy objservice = new CompanyServiceTheraphy();
                                        objservice.ServiceTheraphyArea = theraphy.ServiceTheraphyArea;
                                        cmpView.lstServiceTheraphy.Add(objservice);
                                    }

                                }
                                CompanyIndustry obj = new CompanyIndustry();
                                var details = obj.CompanyIndustryDetails(_companyID);
                                if (details != null)
                                {
                                    cmpView.lstCmpIndustry = new List<CompanyIndustry>();
                                    foreach (var industry in details)
                                    {
                                        CompanyIndustry objindustry = new CompanyIndustry();
                                        objindustry.CompanyIndustryIsPrimary = industry.isPrimary;
                                        objindustry.CompanyIndustryName = industry.fullPath;
                                        cmpView.lstCmpIndustry.Add(objindustry);
                                    }
                                }
                            }
                            else
                            {
                                string errortext = id + " is not valid Company ID";
                                cmpView.Errormsg = errortext;
                            }
                        }
                        else
                        {
                            string errortext = id + " is not valid Company Name";
                            cmpView.Errormsg = errortext;
                        }
                    }
                    else
                    {
                        cmpView.Errormsg = "Please Enter Valid Company ID/Name";
                    }
                    cmpView.lstOtherNames = GetAliasNames(_companyID);
                    cmpView.lstSpideringLinks = GetSpideringLinks(_companyID);
                    cmpView.lstCompanyShareInfo = GetShareInfo(_companyID);
                    cmpView.lstPartneringOppurtunities = GetPartneringoppurtunities(_companyID);
                    cmpView.lstcmpHighlights = GetHighlights(_companyID);
                    cmpView.lstCompanyOffices = GetCompanyOffices(_companyID);
                    cmpView.lstcmpSubsidaryInfo = GetSubsidaryInfoDetails(_companyID);
                    cmpView.lstcmpDocument = GetDocumentDetails(_companyID);
                    cmpView.lstPersons = GetPersonLevelDetails(_companyID);
                    cmpView.lstSocialNetworks = GetSocialNetworks(_companyID);
                   return View(cmpView);
                }
            }
            catch (Exception ex)
            {
               
                log.Error(ex.Message, ex);
                throw ex;

            }
           
        }
    }
}