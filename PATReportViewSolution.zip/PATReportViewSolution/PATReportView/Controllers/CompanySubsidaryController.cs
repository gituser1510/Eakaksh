﻿using AuthoringToolDataAccess;
using PATReportView.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PATReportView.Controllers
{
    public class CompanySubsidaryController : Controller
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(CompanySubsidaryController));
        // GET: CompanySubsidary
        public ActionResult Index()
        {
            return View();
        }

        public List<CompanyOffices> GetCompanyOffices(int _SubcompanyID)
        {

            List<CompanyOffices> lst = new List<CompanyOffices>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var CompanyOffice = companyInfocntx.spGetCompanyOfficesByCompID(_SubcompanyID).ToList();
                    if (CompanyOffice != null)
                    {

                        foreach (var _companyOffices in CompanyOffice)
                        {
                            CompanyOffices objCmpofc = new CompanyOffices();
                            objCmpofc.AddressLine1 = _companyOffices.AddressLine1;
                            objCmpofc.AddressLine1 = _companyOffices.AddressLine2;
                            objCmpofc.AddressLine3 = _companyOffices.AddressLine3;
                            objCmpofc.City = _companyOffices.City;
                            objCmpofc.Country = _companyOffices.Country;
                            objCmpofc.Email = _companyOffices.Email;
                            objCmpofc.Extension = _companyOffices.Extension;
                            objCmpofc.FacilityTypeID = _companyOffices.FacilityTypeKeyName;
                            objCmpofc.Fax = _companyOffices.Fax;
                            objCmpofc.IsActive = Convert.ToBoolean(_companyOffices.IsActive);
                            objCmpofc.IsRegulatoryCertified = Convert.ToBoolean(_companyOffices.IsRegulatoryCertified);
                            objCmpofc.LastUpdatedBy = _companyOffices.LastUpdatedName;
                            // objCmpofc.LastUpdatedDate = Convert.ToBoolean(Convert.ToDateTime(_companyOffices.LastUpdatedDate) == DateTime.MinValue) ? _companyOffices.LastUpdatedDate = null : Convert.ToDateTime(_companyOffices.LastUpdatedDate);

                            objCmpofc.CreatedBy = _companyOffices.CreatedName;
                            if (Convert.ToDateTime(_companyOffices.CreatedDate) != DateTime.MinValue)
                            {
                                objCmpofc.CreatedDate = (Convert.ToDateTime(_companyOffices.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objCmpofc.CreatedDate = "";
                            }

                            if (Convert.ToDateTime(_companyOffices.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objCmpofc.LastUpdatedDate = (Convert.ToDateTime(_companyOffices.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objCmpofc.LastUpdatedDate = "";
                            }


                            objCmpofc.OfficeDetails = _companyOffices.OfficeDetails;
                            objCmpofc.OfficeName = _companyOffices.CompanyName;
                            objCmpofc.Phone = _companyOffices.Phone;
                            objCmpofc.Pincode = _companyOffices.Pincode;
                            objCmpofc.RegulatoryAuthority = _companyOffices.RegulatoryAurhority;
                            string source = _companyOffices.SourceURL;
                            if (source != null)
                            {
                                objCmpofc.SourceURL = source.Split(',');
                            }
                            objCmpofc.State = _companyOffices.State;


                            lst.Add(objCmpofc);
                        }
                    }

                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        public List<CompanyAliasNames> GetCompanyAliasNames(int _SubcompanyID)
        {

            List<CompanyAliasNames> lst = new List<CompanyAliasNames>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var otherNameData = companyInfocntx.spGetCompanyOtherNamesByCompID(_SubcompanyID).ToList();
                    if (otherNameData != null)
                    {

                        foreach (var _aliasNames in otherNameData)
                        {
                            CompanyAliasNames objAliasNames = new CompanyAliasNames();
                            objAliasNames.OtherName = _aliasNames.OtherName;
                            objAliasNames.NameType = _aliasNames.NameType;
                            objAliasNames.FromDay = Convert.ToInt32(_aliasNames.FromDateDay);
                            objAliasNames.FromMonth = Convert.ToInt32(_aliasNames.FromDateMonth);
                            objAliasNames.FromYear = Convert.ToInt32(_aliasNames.FromDateYear);
                            objAliasNames.ToDay = Convert.ToInt32(_aliasNames.ToDateDay);
                            objAliasNames.ToMonth = Convert.ToInt32(_aliasNames.ToDateMonth);
                            objAliasNames.ToYear = Convert.ToInt32(_aliasNames.ToDateYear);
                            //converting comma seperated sourceURL's into array
                            string sourceurl = _aliasNames.SourceURL;
                            if (sourceurl != null)
                            {
                                objAliasNames.SourceURL = sourceurl.Split(',');
                            }

                            objAliasNames.LastUpdatedBy = _aliasNames.LastUpdatedName;
                            objAliasNames.CreatedBy = _aliasNames.CreatedName;
                            if (Convert.ToDateTime(_aliasNames.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objAliasNames.LastUpdatedDate = (Convert.ToDateTime(_aliasNames.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objAliasNames.LastUpdatedDate = "";
                            }
                            if (Convert.ToDateTime(_aliasNames.CreatedDate) != DateTime.MinValue)
                            {
                                objAliasNames.CreatedDate = (Convert.ToDateTime(_aliasNames.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objAliasNames.CreatedDate = "";
                            }
                            //objAliasNames.LastUpdatedDate = Convert.ToBoolean(Convert.ToDateTime(_aliasNames.LastUpdatedDate) == DateTime.MinValue) ? _aliasNames.LastUpdatedDate = null : Convert.ToDateTime(_aliasNames.LastUpdatedDate);
                            lst.Add(objAliasNames);
                        }
                    }
                }
                return lst;
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        public List<CompanySubsidaryInfo> GetCompanySubsidaryInfo(int _companyID, int _SubcompanyID)
        {

            List<CompanySubsidaryInfo> lst = new List<CompanySubsidaryInfo>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var CompanySubsidaryInformation = companyInfocntx.spGetCompanySubsidiaryInformationByCompID(_companyID, _SubcompanyID).ToList();
                    if (CompanySubsidaryInformation != null)
                    {

                        foreach (var _cmpSubsidary in CompanySubsidaryInformation)
                        {
                            CompanySubsidaryInfo objSubsidary = new CompanySubsidaryInfo();
                            objSubsidary.CompanyRelationEndDateDay = Convert.ToInt32(_cmpSubsidary.CompanyRelationEnd_Day);
                            objSubsidary.CompanyRelationEndDateMonth = Convert.ToInt32(_cmpSubsidary.CompanyRelationEnd_Month);
                            objSubsidary.CompanyRelationEndDateYear = Convert.ToInt32(_cmpSubsidary.CompanyRelationEnd_Year);
                            objSubsidary.CompanyRelationStartDateDay = Convert.ToInt32(_cmpSubsidary.CompanyRelationStart_Day);
                            objSubsidary.CompanyRelationStartDateMonth = Convert.ToInt32(_cmpSubsidary.CompanyRelationStart_Month);
                            objSubsidary.CompanyRelationStartDateYear = Convert.ToInt32(_cmpSubsidary.CompanyRelationStart_Year);
                            objSubsidary.RelationshipStatus = _cmpSubsidary.RelationshipStatus;
                            objSubsidary.RelationshipType = _cmpSubsidary.RelationshipType;
                            objSubsidary.SubsidaryCompanyName = _cmpSubsidary.SubsidiaryName;
                            objSubsidary.SubsidaryCompanyID = Convert.ToInt32(_cmpSubsidary.SubsidiaryID);
                            objSubsidary.OwnershipPercent = Convert.ToInt32(_cmpSubsidary.OwnershipPercentage);
                            objSubsidary.OwnerShipShares = Convert.ToInt32(_cmpSubsidary.OwnershipShares);
                            objSubsidary.JointVentureCompanyID = Convert.ToInt32(_cmpSubsidary.JointVentureCompanyId);
                            objSubsidary.JointVentureCompanyName = _cmpSubsidary.JointVentureCompany;
                            //  objSubsidary.IsActive = Convert.ToBoolean(_cmpSubsidary.PSType);
                            // objSubsidary.CountryID=Convert.ToInt32(_cmpSubsidary.)
                            lst.Add(objSubsidary);

                        }
                    }

                }
                return lst;
            }
            catch (Exception ex)
            {

                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        public ActionResult SubsidaryCompanyDetails(int _companyID, int _SubcompanyID)
        {
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    CompanyViewModel cmpView = new CompanyViewModel();


                    spGetCompanyInfoByCompID_Result companyInfoDetails = companyInfocntx.spGetCompanyInfoByCompID(_SubcompanyID).SingleOrDefault();
                    //Getting Logo
                    var companyLogo = (from i in companyInfocntx.CompanyLogoImages.Where(x => x.CompanyID == _companyID && x.IsActive == true) select i).SingleOrDefault();
                    if (companyLogo != null)
                    {
                        MemoryStream ms = new MemoryStream((byte[])companyLogo.CompanyLogoImage1);
                        cmpView.LogoUrl = ms.ToArray();
                    }
                    if (companyInfoDetails != null)
                    {
                        cmpView.CompanyName = companyInfoDetails.CompanyName;
                        cmpView.CompanyID = companyInfoDetails.CompanyID;
                        cmpView.FiscalYearEnd = companyInfoDetails.FiscalYearEnd;
                        cmpView.IsPublic = Convert.ToBoolean(companyInfoDetails.IsPublic);
                        cmpView.TickerSymbol = companyInfoDetails.TickerSymbol;
                        cmpView.CompanyEmployeeCount = Convert.ToInt32(companyInfoDetails.CompanyEmployeeCount);
                        cmpView.IsserviceProvider = Convert.ToBoolean(companyInfoDetails.IsServiceProvider);
                        cmpView.ActualInactiveDate = Convert.ToBoolean(Convert.ToDateTime(companyInfoDetails.ActualInactiveDate) == DateTime.MinValue) ? companyInfoDetails.ActualInactiveDate = null : Convert.ToDateTime(companyInfoDetails.ActualInactiveDate);
                        cmpView.InactiveReason = companyInfoDetails.InActiveReasonKeyName;
                        cmpView.LogoPath = companyInfoDetails.LogoURL;
                        cmpView.CategoryKey = companyInfoDetails.CategoryKeyName;
                        cmpView.CompanyType = companyInfoDetails.CompanyTypeKeyName;
                        cmpView.CompanyStatus = companyInfoDetails.CompanyStatusKeyName;
                        cmpView.InactiveDate = Convert.ToBoolean(Convert.ToDateTime(companyInfoDetails.InActiveDate) == DateTime.MinValue) ? companyInfoDetails.InActiveDate = null : Convert.ToDateTime(companyInfoDetails.InActiveDate);
                        cmpView.LastUpdatedBy = companyInfoDetails.LastUpdatedName;
                        cmpView.CreatedBy = companyInfoDetails.CreatedName;
                        if (Convert.ToDateTime(companyInfoDetails.LastUpdatedDate) != DateTime.MinValue)
                        {
                            cmpView.LastUpdatedDate = (Convert.ToDateTime(companyInfoDetails.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            cmpView.LastUpdatedDate = "";
                        }
                        if (Convert.ToDateTime(companyInfoDetails.CreatedDate) != DateTime.MinValue)
                        {
                            cmpView.CreatedDate = (Convert.ToDateTime(companyInfoDetails.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            cmpView.CreatedDate = "";
                        }
                        // cmpView.LastUpdatedDate = Convert.ToBoolean(Convert.ToDateTime(companyInfoDetails.LastUpdatedDate) == DateTime.MinValue) ? companyInfoDetails.LastUpdatedDate = null : Convert.ToDateTime(companyInfoDetails.LastUpdatedDate);
                        cmpView.HasPartneringOppurtunities = Convert.ToBoolean(companyInfoDetails.HasPartneringOpportunities);
                        cmpView.HasSubsidary = Convert.ToBoolean(companyInfoDetails.HasSubsidary);
                        cmpView.Description = companyInfoDetails.Description;
                        if (!((companyInfoDetails.IPO_DateDay == 0 || companyInfoDetails.IPO_DateDay == null) && (companyInfoDetails.IPO_DateMonth == 0 || companyInfoDetails.IPO_DateMonth == null) && (companyInfoDetails.IPO_DateYear == 0 || companyInfoDetails.IPO_DateYear == null)))
                        {
                            cmpView.IPODate = (((companyInfoDetails.IPO_DateDay) == 0 ? "--" : Convert.ToString(companyInfoDetails.IPO_DateDay)) + "/" + (companyInfoDetails.IPO_DateMonth == 0 ? "--" : Convert.ToString(companyInfoDetails.IPO_DateMonth)) + "/" + (companyInfoDetails.IPO_DateYear == 0 ? "--" : Convert.ToString(companyInfoDetails.IPO_DateYear)));
                        }
                        else
                        {
                            cmpView.IPODate = "NA";
                        }

                        //cmpView.IPODate=companyInfoDetails.ip
                        //converting comma seperated sourceURL's into array
                        string source = companyInfoDetails.SourceURL;
                        if (source != null)
                        {
                            cmpView.SourceUrl = source.Split(',');
                        }
                        if (!((companyInfoDetails.InCorporationDateDay == 0 || companyInfoDetails.InCorporationDateDay == null) && (companyInfoDetails.InCorporationDateMonth == 0 || companyInfoDetails.InCorporationDateMonth == null) && (companyInfoDetails.InCorporationDateYear == 0 || companyInfoDetails.InCorporationDateYear == null)))
                        {
                            cmpView.InCorporationDateDay = (((companyInfoDetails.InCorporationDateDay) == 0 ? "--" : Convert.ToString(companyInfoDetails.InCorporationDateDay)) + "/" + (companyInfoDetails.InCorporationDateMonth == 0 ? "--" : Convert.ToString(companyInfoDetails.InCorporationDateMonth)) + "/" + (companyInfoDetails.InCorporationDateYear == 0 ? "--" : Convert.ToString(companyInfoDetails.InCorporationDateYear)));
                        }
                        else
                        {
                            cmpView.InCorporationDateDay = "NA";
                        }


                        CompanyServiceTheraphy objTheraphy = new CompanyServiceTheraphy();
                        var ServiceTheraphyName = objTheraphy.ServiceTheraphy(_SubcompanyID);
                        if (ServiceTheraphyName != null)
                        {
                            cmpView.lstServiceTheraphy = new List<CompanyServiceTheraphy>();
                            foreach (var theraphy in ServiceTheraphyName)
                            {
                                CompanyServiceTheraphy objservice = new CompanyServiceTheraphy();
                                objservice.ServiceTheraphyArea = theraphy.ServiceTheraphyArea;
                                cmpView.lstServiceTheraphy.Add(objservice);
                            }

                        }
                        CompanyIndustry obj = new CompanyIndustry();
                        var details = obj.CompanyIndustryDetails(_SubcompanyID);
                        if (details != null)
                        {
                            cmpView.lstCmpIndustry = new List<CompanyIndustry>();
                            foreach (var industry in details)
                            {
                                CompanyIndustry objindustry = new CompanyIndustry();
                                objindustry.CompanyIndustryIsPrimary = industry.isPrimary;
                                objindustry.CompanyIndustryName = industry.fullPath;
                                cmpView.lstCmpIndustry.Add(objindustry);
                            }

                        }
                    }
                    cmpView.lstcmpSubsidaryInfo = GetCompanySubsidaryInfo(_companyID, _SubcompanyID);
                    cmpView.lstOtherNames = GetCompanyAliasNames(_SubcompanyID);
                    cmpView.lstCompanyOffices = GetCompanyOffices(_SubcompanyID);
                    return PartialView("_SubsidaryCompanyDetails", cmpView);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }

        }
    }
}