﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AuthoringToolDataAccess;
using AuthoringToolTaxonomies;
using PATReportView.Models.Product;
using System.Text.RegularExpressions;
using System.Globalization;

namespace PATReportView.Controllers
{
    public class ProductViewController : Controller
    {

        int productID;
        string[] strItems;
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(ProductViewController));

        //Getting ProductNamesfor Autocomplete TextBox
        public ActionResult Search(string term)
        {

            // CompanyInfoEntities cmp = new CompanyInfoEntities();
            using (var companyInfocntx = new CompanyInfoContext())
            {
                var _prdName = (from product in companyInfocntx.ProductInfoes
                                where product.ProductName.StartsWith(term)
                                select product.ProductName).Distinct().ToList();
                List<string> lst = new List<string>();

                foreach (var prdname in _prdName)
                {
                    lst.Add(prdname.ToString());

                }
                return Json(lst, JsonRequestBehavior.AllowGet);
            }


        }
        // GET: ProductView
        public ActionResult Index()
        {
            return View();
        }

        //For Getting Phases Based on Indications
        public ActionResult FillIndication(int state)
        {
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    List<Phase> lstPhase = new List<Phase>();

                    var phases = companyInfocntx.spGetReportPrdPhasesByPrdInd(state).ToList();
                    foreach (var phase in phases)
                    {
                        Phase objphase = new Phase();
                        objphase.InactiveReasonName = phase.InactiveReasonName==null?"": phase.InactiveReasonName;
                        if ((phase.PhaseEndDate != "\\\\") && (phase.PhaseEndDate != "0\\0\\0"))
                        {
                            objphase.PhaseEndDate = phase.PhaseEndDate;
                        }
                        else
                        {
                            objphase.PhaseEndDate = "NA";
                        }

                        objphase.PhaseName = phase.PhaseName==null?"": phase.PhaseName;
                        objphase.ProductIndPhaseDetailsID = Convert.ToInt32(phase.ProductIndPhaseDetailsID);
                        if (phase.PhaseStartDate != "\\\\" && (phase.PhaseStartDate != "0\\0\\0"))
                        {
                            objphase.PhaseStartDate = phase.PhaseStartDate;
                        }
                        else
                        {
                            objphase.PhaseStartDate = "NA";
                        }
                        //string source = phase.Source;
                        //if (source != null)
                        //{
                        //    string[] separators = { ",", "\r\n" };
                        //    string[] sourceURL = source.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                        //    objphaseTrialDetails.SourceLinks = sourceURL;
                        //}
                        objphase.PhaseStatus = phase.PhaseStatus;
                        objphase.TrialUpdatesCount = Convert.ToString(phase.TrialUpdatesCount);
                        objphase.Companys = phase.Companys;
                        objphase.CreatedBy = phase.CreatedName;
                        objphase.LastUpdatedBy = phase.LastUpdatedName == null ? "" : phase.LastUpdatedName;
                        if (Convert.ToDateTime(phase.CreatedDate) != DateTime.MinValue)
                        {
                            objphase.CreatedDate = (Convert.ToDateTime(phase.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objphase.CreatedDate = "";
                        }

                        if (Convert.ToDateTime(phase.LastUpdatedDate) != DateTime.MinValue)
                        {
                            objphase.LastUpdatedDate = (Convert.ToDateTime(phase.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objphase.LastUpdatedDate = "";
                        }
                        //objphase.SourceURL=phase
                        lstPhase.Add(objphase);
                    }
                    return Json(lstPhase, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        //For Getting TrialDates Based on Phase
        public ActionResult FillTrialDates(int state)
        {
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    List<PhaseDetails> lstPhasedetals = new List<PhaseDetails>();

                    var phasesTrials = companyInfocntx.spGetReportPrdPhaseTrailsbyPhaseDetailID(state).ToList();
                    foreach (var phaseDetails in phasesTrials)
                    {
                        PhaseDetails objphaseTrialDetails = new PhaseDetails();
                        if (phaseDetails.TrialDate != "\\\\" && (phaseDetails.TrialDate != "0\\0\\0") && (phaseDetails.TrialDate != ""))
                        {
                            objphaseTrialDetails.TrialDate = phaseDetails.TrialDate;
                        }
                        else
                        {
                            objphaseTrialDetails.TrialDate = "NA";
                        }
                        objphaseTrialDetails.TrailDetails = phaseDetails.TrialUpdates;
                        // objphaseTrialDetails.TrialDate = phaseDetails.TrialDate;
                        objphaseTrialDetails.TrialDistinguisherName = phaseDetails.TrialDistinguisherName;
                        objphaseTrialDetails.IsActive = phaseDetails.IsActive;
                         string source = phaseDetails.SourceLinks;                       
                        if (source != null)
                        {
                            string[] separators = { ",", "\r\n"};
                            string[] sourceURL = source.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                            objphaseTrialDetails.SourceLinks = sourceURL;
                        }                        
                        objphaseTrialDetails.Summary = phaseDetails.TrialSummary;
                        objphaseTrialDetails.CreatedBy = phaseDetails.CreatedName;
                        objphaseTrialDetails.LastUpdatedBy = phaseDetails.LastUpdatedName == null ? "" : phaseDetails.LastUpdatedName;
                        if (Convert.ToDateTime(phaseDetails.CreatedDate) != DateTime.MinValue)
                        {
                            objphaseTrialDetails.CreatedDate = (Convert.ToDateTime(phaseDetails.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objphaseTrialDetails.CreatedDate = "";
                        }

                        if (Convert.ToDateTime(phaseDetails.LastUpdatedDate) != DateTime.MinValue)
                        {
                            objphaseTrialDetails.LastUpdatedDate = (Convert.ToDateTime(phaseDetails.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objphaseTrialDetails.LastUpdatedDate = "";
                        }
                        lstPhasedetals.Add(objphaseTrialDetails);
                    }
                    return Json(lstPhasedetals, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        //For Company Details Geo Details,Dosage Details BY Indication,Phase and CompanyInvolved
        public ActionResult FillCompanyDetails(int state)
        {
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    ProductViewModel obj = new ProductViewModel();
                    obj.lstDosageDetails = new List<Models.Product.DosageDetails>();
                    obj.lstCompanyDetails = new List<Companydetails>();
                    obj.lstGeoExcluded = new List<GeoExcludeDetails>();
                    obj.lstGeoIncluded = new List<Models.Product.GeoIncludeDetails>();
                    //List<Companydetails> lstCompanyDetails = new List<Companydetails>();
                    //List<DosageDetails> lstDosageDetails = new List<Models.Product.DosageDetails>();
                    var ComapnyDetails = companyInfocntx.spGetReportPrdIndCompInvolByID(state).ToList();
                    var DosageDetails = companyInfocntx.SpGetReportPrdDosageByinvolvedID(state).ToList();
                    var GeoIncludeDetails = companyInfocntx.spGetReportGeoIncByGeoDetailByID(state).ToList();
                    var GeoExcludeDetails = companyInfocntx.spGetReportGeoExcByGeoDetailByID(state).ToList();
                    foreach (var compDetails in ComapnyDetails)
                    {
                        Companydetails objComapnyDetails = new Companydetails();
                        objComapnyDetails.InvolvementStatus = compDetails.InvolvementStatusName;
                        objComapnyDetails.CompanyRole = compDetails.CompanyRoleNames;
                        objComapnyDetails.CompanyReportedIndication = compDetails.CompReportedIndication;
                        objComapnyDetails.PartneringOpportunit = compDetails.PartneringOpportunityName;
                        objComapnyDetails.Agreement = compDetails.AgreementNotes==null?"": compDetails.AgreementNotes;
                        if (compDetails.PatneringDealID != null)
                        {
                            objComapnyDetails.DealId = compDetails.PatneringDealID;
                        }
                        else {
                            objComapnyDetails.DealId = "";
                        }
                        if (compDetails.POFuturisticPhaseName != null)
                        {
                            objComapnyDetails.POFuturisticPhase = compDetails.POFuturisticPhaseName;
                        }
                        else
                        {
                            objComapnyDetails.POFuturisticPhase = "";
                        }
                        if (compDetails.PONotes != "0")
                        {
                            objComapnyDetails.PONotes = compDetails.PONotes;
                        }
                        else
                        {
                            objComapnyDetails.PONotes = "";
                        }
                        if (!((compDetails.CompInvolveStartDate_Day == 0 || compDetails.CompInvolveStartDate_Day == null) && (compDetails.CompInvolveStartDate_Month == 0 || compDetails.CompInvolveStartDate_Month == null) && (compDetails.CompInvolveStartDate_Year == 0 || compDetails.CompInvolveStartDate_Year == null)))
                        {
                            objComapnyDetails.StartDate = (((compDetails.CompInvolveStartDate_Day) == 0 ? "--" : Convert.ToString(compDetails.CompInvolveStartDate_Day)) + "/" + (compDetails.CompInvolveStartDate_Month == 0 ? "--" : Convert.ToString(compDetails.CompInvolveStartDate_Month)) + "/" + (compDetails.CompInvolveStartDate_Year == 0 ? "--" : Convert.ToString(compDetails.CompInvolveStartDate_Year)));
                        }
                        else
                        {
                            objComapnyDetails.StartDate = "NA";
                        }



                        if (!((compDetails.CompInvolveEndDate_Day == 0 || compDetails.CompInvolveEndDate_Day == null) && (compDetails.CompInvolveEndDate_Month == 0 || compDetails.CompInvolveEndDate_Month == null) && (compDetails.CompInvolveEndDate_Year == 0 || compDetails.CompInvolveEndDate_Year == null)))
                        {
                            objComapnyDetails.EndDate = (((compDetails.CompInvolveEndDate_Day) == 0 ? "--" : Convert.ToString(compDetails.CompInvolveEndDate_Day)) + "/" + (compDetails.CompInvolveEndDate_Month == 0 ? "--" : Convert.ToString(compDetails.CompInvolveEndDate_Month)) + "/" + (compDetails.CompInvolveEndDate_Year == 0 ? "--" : Convert.ToString(compDetails.CompInvolveEndDate_Year)));
                        }
                        else
                        {
                            objComapnyDetails.EndDate = "NA";
                        }
                        if (compDetails.LineOfTherapy != "0")
                        {
                            objComapnyDetails.LineofTherapy = compDetails.LineOfTherapy;
                        }
                        else
                        {
                            objComapnyDetails.LineofTherapy = "";
                        }
                        // objComapnyDetails.POPartnershipType=compDetails.pa
                        if (!((compDetails.POUpdatedDateDay == 0 || compDetails.POUpdatedDateDay == null) && (compDetails.POUpdatedDateMonth == 0 || compDetails.POUpdatedDateMonth == null) && (compDetails.POUpdatedDateYear == 0 || compDetails.POUpdatedDateYear == null)))
                        {
                            objComapnyDetails.POUpdatedDate = (compDetails.POUpdatedDateDay + "/" + compDetails.POUpdatedDateMonth + "/" + compDetails.POUpdatedDateYear);
                        }
                        else
                        {
                            objComapnyDetails.POUpdatedDate = "NA";
                        }

                        objComapnyDetails.SourceURLs = compDetails.SourceURL;
                        objComapnyDetails.CreatedBy = compDetails.CreatedName == null ? "" : compDetails.CreatedName;
                        objComapnyDetails.UpdatedBy = compDetails.LastUpdatedName == null ? "" : compDetails.LastUpdatedName;
                        objComapnyDetails.CreatedDate = Convert.ToString(compDetails.CreatedDate);
                        objComapnyDetails.UpdatedDate = Convert.ToString(compDetails.LastUpdatedDate);

                        obj.lstCompanyDetails.Add(objComapnyDetails);
                    }
                    foreach (var DosDetails in DosageDetails)
                    {
                        DosageDetails objDosageDetails = new DosageDetails();
                        objDosageDetails.DosageDeails = DosDetails.DosageDetails == null ? "NA" : DosDetails.DosageDetails;
                        objDosageDetails.DosageForm = DosDetails.DosageForm == null ? "NA" : DosDetails.DosageForm;
                        objDosageDetails.MarketingStatus = DosDetails.MarketingStatus == null ? "NA" : DosDetails.MarketingStatus;
                        objDosageDetails.ROA = DosDetails.ROAName == null ? "NA" : DosDetails.ROAName;
                        objDosageDetails.Strength = DosDetails.Strength == null ? "NA" : DosDetails.Strength;
                        //objDosageDetails.SourceURL = DosDetails.SourceURL == null ? "NA" : DosDetails.SourceURL;
                        string source = DosDetails.SourceURL;
                        if (source != null)
                        {
                            string[] separators = { ",", "\r\n" };
                            string[] sourceURL = source.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                            objDosageDetails.SourceURL = sourceURL;
                        }
                        objDosageDetails.CreatedBy = DosDetails.CreatedName == null ? "" : DosDetails.CreatedName;
                        //objDosageDetails.CreatedDate = Convert.ToString(DosDetails.CreatedDate);
                        objDosageDetails.UpdatedBy = DosDetails.LastUpdatedName == null ? "" : DosDetails.LastUpdatedName;
                        //objDosageDetails.UpdatedDate = Convert.ToString(DosDetails.LastUpdatedDate);
                        if (Convert.ToDateTime(DosDetails.CreatedDate) != DateTime.MinValue)
                        {
                            objDosageDetails.CreatedDate = (Convert.ToDateTime(DosDetails.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objDosageDetails.CreatedDate = "";
                        }

                        if (Convert.ToDateTime(DosDetails.LastUpdatedDate) != DateTime.MinValue)
                        {
                            objDosageDetails.UpdatedDate = (Convert.ToDateTime(DosDetails.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objDosageDetails.UpdatedDate = "";
                        }
                        obj.lstDosageDetails.Add(objDosageDetails);

                    }
                    foreach (var GeoInclude in GeoIncludeDetails)
                    {
                        GeoIncludeDetails objGeoInclude = new Models.Product.GeoIncludeDetails();
                        objGeoInclude.GeoIncludedCountry = GeoInclude.Country == null ? "NA" : GeoInclude.Country;
                        objGeoInclude.Region = GeoInclude.RegionName == null ? "NA" : GeoInclude.RegionName;
                        // objGeoInclude.SourceURL = GeoInclude.SourceURLs == null ? "NA" : GeoInclude.SourceURLs;
                        string source = GeoInclude.SourceURLs;
                        if (source != null)
                        {
                            string[] separators = { ",", "\r\n" };
                            string[] sourceURL = source.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                            objGeoInclude.SourceURL = sourceURL;
                        }
                        objGeoInclude.Status = GeoInclude.StatusName == null ? "NA" : GeoInclude.StatusName;
                        objGeoInclude.NameType = GeoInclude.NameType == null ? "NA" : GeoInclude.NameType;
                        objGeoInclude.ProductOtherName = GeoInclude.OtherNames == null ? "NA" : GeoInclude.OtherNames;
                        objGeoInclude.CreatedBy = GeoInclude.CreatedName == null ? "NA" : GeoInclude.CreatedName;
                        objGeoInclude.CreatedDate = Convert.ToString(GeoInclude.CreatedDate);
                        objGeoInclude.UpdatedBy = GeoInclude.LastUpdatedName == null ? "NA" : GeoInclude.LastUpdatedName; ;
                        objGeoInclude.UpdatedDate = Convert.ToString(GeoInclude.LastUpdatedDate);
                        obj.lstGeoIncluded.Add(objGeoInclude);
                    }
                    foreach (var GeoExclude in GeoExcludeDetails)
                    {
                        GeoExcludeDetails objGeoExclude = new Models.Product.GeoExcludeDetails();
                        objGeoExclude.GeoExcludedCountry = GeoExclude.Country == null ? "NA" : GeoExclude.Country;
                        objGeoExclude.Region = GeoExclude.RegionName == null ? "NA" : GeoExclude.RegionName;
                        objGeoExclude.CreatedBy = GeoExclude.CreatedName == null ? "NA" : GeoExclude.CreatedName;

                        objGeoExclude.CreatedDate = Convert.ToString(GeoExclude.CreatedDate);
                        objGeoExclude.UpdatedBy = GeoExclude.LastUpdatedName == null ? "NA" : GeoExclude.LastUpdatedName;
                        objGeoExclude.UpdatedDate = Convert.ToString(GeoExclude.LastUpdatedDate);
                        //objGeoInclude.ProductOtherName = GeoExclude.OtherNames;
                        obj.lstGeoExcluded.Add(objGeoExclude);
                    }
                    return Json(obj, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        //Milestones
        public List<Milestones> GetMileStone(int id)
        {
            List<Milestones> lst = new List<Milestones>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var _Milestone = companyInfocntx.spGetReportMileStoneByPrdID(productID).ToList();
                    if (_Milestone != null)
                    {

                        foreach (var milestone in _Milestone)
                        {
                            Milestones objMilestones = new Milestones();
                            if (Convert.ToDateTime(milestone.EstimatedMilestoneEndDate) != DateTime.MinValue)
                            {
                                objMilestones.EstimatedMilestoneEndDate = (Convert.ToDateTime(milestone.EstimatedMilestoneEndDate)).ToString("dd/MM/yyyy");

                            }
                            else
                            {
                                objMilestones.EstimatedMilestoneEndDate = "";
                            }
                            if (Convert.ToDateTime(milestone.EstimatedMilestoneStartDate) != DateTime.MinValue)
                            {
                                objMilestones.EstimatedMilestoneStartDate = (Convert.ToDateTime(milestone.EstimatedMilestoneStartDate)).ToString("dd/MM/yyyy");

                            }
                            else
                            {
                                objMilestones.EstimatedMilestoneStartDate = "";
                            }

                            //  objMilestones.CurrentPhaseName=milestone.c
                            objMilestones.NewsID = Convert.ToString(milestone.NewsID);
                            objMilestones.SourceName = milestone.SourceName;
                            objMilestones.MilestonePhase = milestone.MileStonePhaseName;
                            objMilestones.MilestoneGeography = milestone.MilestoneGeography;
                            objMilestones.MilestoneHeadline = milestone.MilestoneHeadline;
                            objMilestones.CreatedBy = milestone.CreatedName;
                            //objMilestones.MilestoneDate = (milestone.MilestoneDate);
                            if (Convert.ToDateTime(milestone.MilestoneDate) != DateTime.MinValue)
                            {
                                objMilestones.MilestoneDate = (Convert.ToDateTime(milestone.MilestoneDate)).ToString("dd/MM/yyyy");
                            }
                            else
                            {
                                objMilestones.MilestoneDate = "";
                            }

                            objMilestones.PDUFADate = Convert.ToString(milestone.PDUFADate);
                            string Milestonesource = milestone.SourceURL;
                            if (Milestonesource != null)
                            {
                                objMilestones.SourceURLs = Milestonesource.Split(',');
                            }
                           // objMilestones.SourceURLs = milestone.SourceURL;
                            objMilestones.MilestoneClassCategory = milestone.MileStoneClassCategoryName;
                            objMilestones.AsReportedAchievedDate = milestone.AsReportedAchievedDate;
                            objMilestones.AsReportedEndDate = milestone.AsReportedEndDate;
                            objMilestones.AsReportedStartDate = milestone.AsReportedStartDate;
                            objMilestones.ClinicaltrialRegistryID = milestone.ClinicalTrialRegistry;
                            objMilestones.LastUpdatedBy = milestone.LastUpdatedName;
                            if (Convert.ToDateTime(milestone.LastUpdatedDate) != DateTime.MinValue)
                            {
                                objMilestones.LastUpdatedDate = (Convert.ToDateTime(milestone.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                                
                            }
                            else
                            {
                                objMilestones.LastUpdatedDate = "";
                            }
                            if (Convert.ToDateTime(milestone.CreatedDate) != DateTime.MinValue)
                            {
                                objMilestones.CreatedDate = (Convert.ToDateTime(milestone.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                objMilestones.CreatedDate = "";
                            }
                            //  objMilestones.LastUpdatedDate = Convert.ToString(milestone.LastUpdatedDate);
                            objMilestones.MilestoneBrief = milestone.MileStoneBriefName;
                            //objMilestones.MilestoneAchieveddate=milestone.
                            lst.Add(objMilestones);
                        }
                    }
                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        //For Indications of Phase and Trial Details
        public List<Indications> GetPhaseandTrialDetails(int id)
        {
            // List<PhaseandTrialDetails> lst = new List<PhaseandTrialDetails>();
            List<Indications> lst = new List<Indications>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var _PhaseTrialIndications = companyInfocntx.spGetReportPrdIndicationByPrdID(productID).ToList();
                    if (_PhaseTrialIndications != null)
                    {

                        foreach (var _PhaseTrialInd in _PhaseTrialIndications)
                        {
                            PhaseandTrialDetails phaseandTrial = new PhaseandTrialDetails();
                            Indications lstInd = new Indications();
                            lstInd.ProductIndicationID = _PhaseTrialInd.ProductIndicationID;
                            lstInd.TherapeuticIndicationName = _PhaseTrialInd.TherapeuticIndicationName;
                            lst.Add(lstInd);
                        }
                    }
                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        //CompanyInvolvement
        public List<ProductCompanyInvolvement> GetPrdCompanyInvolvement(int id)
        {
            List<ProductCompanyInvolvement> lst = new List<ProductCompanyInvolvement>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var _CompanyInvolvementMain = companyInfocntx.spGetReportCompInvoByPrdID(productID).ToList();
                    if (_CompanyInvolvementMain != null)
                    {

                        foreach (var _CompanyInvol in _CompanyInvolvementMain)
                        {
                            ProductCompanyInvolvement obj = new ProductCompanyInvolvement();
                            obj.ProductIndCompInvolvementID = (_CompanyInvol.ProductIndCompInvolvementID);
                            obj.CompanyName = _CompanyInvol.CompanyName;
                            obj.PhaseName = _CompanyInvol.PhaseName;
                            obj.TherapeuticIndicationName = _CompanyInvol.TherapeuticIndicationName;
                            obj.CreatedBy = _CompanyInvol.CreatedName;
                            obj.UpdatedBy = _CompanyInvol.LastUpdatedName == null ? "" : _CompanyInvol.LastUpdatedName;
                            if (Convert.ToDateTime(_CompanyInvol.CreatedDate) != DateTime.MinValue)
                            {
                                obj.CreatedDate = (Convert.ToDateTime(_CompanyInvol.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                obj.CreatedDate = "";
                            }
                            if (Convert.ToDateTime(_CompanyInvol.LastUpdatedDate) != DateTime.MinValue)
                            {
                                obj.UpdatedDate = (Convert.ToDateTime(_CompanyInvol.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                obj.UpdatedDate = "";
                            }
                            lst.Add(obj);
                        }
                    }
                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }

        //Taxonomies
        public List<ProductTaxonomies> GetPrdTaxonomies(int id)
        {
            List<ProductTaxonomies> lst = new List<ProductTaxonomies>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var _Taxonomies = companyInfocntx.spGetReportPrdTaxonomiesDetailsByID(productID).ToList();
                    if (_Taxonomies != null)
                    {
                        foreach (var _Tax in _Taxonomies)
                        {
                            ProductTaxonomies taxonomies = new ProductTaxonomies();
                            taxonomies.IndicationNames = _Tax.IndicationNames;
                            taxonomies.MOA = _Tax.MOA;
                            taxonomies.ModeofAction = _Tax.ModeofAction;
                            taxonomies.ROA = _Tax.ROA;
                            taxonomies.ATC = _Tax.ATC;
                            taxonomies.CreatedName = _Tax.CreatedBy;
                            taxonomies.LastUpdatedName = _Tax.LastUpdatedBy;
                            if (Convert.ToDateTime(_Tax.CreatedDate) != DateTime.MinValue)
                            {
                                taxonomies.CreatedDate = (Convert.ToDateTime(_Tax.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                taxonomies.CreatedDate = "";
                            }

                            if (Convert.ToDateTime(_Tax.LastUpdateddate) != DateTime.MinValue)
                            {
                                taxonomies.LastUpdatedDate = (Convert.ToDateTime(_Tax.LastUpdateddate)).ToString("dd-MMM-yyyy hh:mm:ss");
                            }
                            else
                            {
                                taxonomies.LastUpdatedDate = "";
                            }
                            lst.Add(taxonomies);
                        }
                    }

                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        public ActionResult Product(string id)
        {
            ProductViewModel prdView = new ProductViewModel();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {


                    Regex r = new Regex("^[0-9]*$");
                    if (id != null && id != "")
                    {
                        if (r.IsMatch(id))
                        {
                            productID = Convert.ToInt32(id);
                        }
                        else
                        {
                            //Gettind ProductID based on Product Name
                            var ID = (from cmpInfo in companyInfocntx.ProductInfoes
                                      where cmpInfo.ProductName == id
                                      select cmpInfo.ProductID).SingleOrDefault();
                            productID = ID;

                        }
                        if (productID != 0)
                        {
                            var _parmacology = companyInfocntx.spGetProductPharmacologyByProdID(0, productID).SingleOrDefault();
                            
                           
                          

                            if (_parmacology != null)
                            {
                                prdView.Toxicology = _parmacology.Toxicology;
                                prdView.AdditionalSponsoredWebsites = _parmacology.Additional;
                                prdView.AdverseEffects = _parmacology.AdverseEffects;
                                prdView.BlackBoxWarning = _parmacology.BlackBoxWarning;
                                prdView.ContraIndications = _parmacology.ContraIndications;
                                prdView.DrugInteractions = _parmacology.DrugInteractions;
                                prdView.ScheduleDrug = _parmacology.ScheduleDrugName;
                                prdView.ProductWebsite = _parmacology.WebsiteURLs;
                                prdView.ProductLabelLink = _parmacology.ProductLabelLink;
                                prdView.ProductName = _parmacology.ProductName;
                                prdView.ProductID = productID;
                                prdView.BlackBox = _parmacology.IsBlackBoxName;
                                prdView.Pharmadynamics = _parmacology.PharmaDynamics;
                                prdView.Pharmacokinetics = _parmacology.PharmacoKinetics;
                                prdView.CreatedBy = _parmacology.CreatedName;

                                prdView.LastUpdatedBy = _parmacology.LastUpdatedName;
                                if (Convert.ToDateTime(_parmacology.LastUpdatedDate) != DateTime.MinValue)
                                {
                                    prdView.LastUpdatedDate = (Convert.ToDateTime(_parmacology.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                                }
                                else
                                {
                                    prdView.LastUpdatedDate = "";
                                }

                                if (Convert.ToDateTime(_parmacology.CreatedDate) != DateTime.MinValue)
                                {
                                    prdView.CreatedDate = (Convert.ToDateTime(_parmacology.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                                }
                                else
                                {
                                    prdView.CreatedDate = "";
                                }
                            }



                            //Product Basic Deatils
                            var _basicInfo = companyInfocntx.spGetProductInfoByProdID(productID).ToList();
                            if (_basicInfo != null)
                            {
                                prdView.lstProductBasicInfo = new List<ProductBasicInfoViewModel>();
                                foreach (var _basicData in _basicInfo)
                                {
                                    ProductBasicInfoViewModel basicInfos = new ProductBasicInfoViewModel();
                                    basicInfos.ProducID = productID;
                                    basicInfos.ProductName = _basicData.ProductName;
                                    basicInfos.ProductTypeName = _basicData.ProductTypeName;
                                    basicInfos.ProductDescription = _basicData.ProductDescription;
                                    basicInfos.ProductWebsite = _basicData.ProductWebsite;
                                    basicInfos.ProductCategoryName = _basicData.ProductCategoryName;
                                    basicInfos.TreatmentTypeName = _basicData.TreatmentTypeName;
                                    basicInfos.MoleculeTypeName = _basicData.MoleculeTypeName;
                                    basicInfos.Notes = _basicData.Notes;
                                    basicInfos.ActiveIngredientName = _basicData.ActiveIngredientName;
                                    basicInfos.CreatedName = _basicData.CreatedName;
                                    if (Convert.ToDateTime(_basicData.CreatedDate) != DateTime.MinValue)
                                    {
                                        basicInfos.CreatedDate = (Convert.ToDateTime(_basicData.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                                    }
                                    else
                                    {
                                        basicInfos.CreatedDate = "";
                                    }
                                    basicInfos.LastUpdatedName = _basicData.LastUpdatedName;
                                    if (Convert.ToDateTime(_basicData.LastUpdatedDate) != DateTime.MinValue)
                                    {
                                        basicInfos.LastUpdatedDate = (Convert.ToDateTime(_basicData.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                                    }
                                    else
                                    {
                                        basicInfos.LastUpdatedDate = "";
                                    }
                                    prdView.lstProductBasicInfo.Add(basicInfos);
                                }


                                 var TreeView = companyInfocntx.spGetProductAICBNamesByProductID(productID).ToList();
                                //  var TreeView = companyInfocntx.spGetProductAICBNamesByProductID(4208).ToList();
                                prdView.lstChemicalBiologicalClassification = new List<ChemicalBiologicalClassification>();
                                prdView.lsttreeCB = new List<TreeViewLocation>();
                                List<ChemicalBiologicalClassification> lst = new List<ChemicalBiologicalClassification>();
                                foreach (var _treeViewCB in TreeView)
                                {
                                    ChemicalBiologicalClassification obj = new ChemicalBiologicalClassification();
                                    TreeViewLocation objtree = new TreeViewLocation();
                                    if (_treeViewCB.Chemical_BiologicalClassfSeqNames != null)
                                    {
                                        strItems = _treeViewCB.Chemical_BiologicalClassfSeqNames.Split('\\');
                                        obj.lsttreeCB = obj.GetLocations(strItems);
                                        obj.ActiveIngredients = _treeViewCB.ActiveIngredientName;
                                        prdView.lstChemicalBiologicalClassification.Add(obj);
                                    }
                                    else
                                    {
                                        obj.lsttreeCB = null;
                                        obj.ActiveIngredients = "";
                                    }                                  
                                }
                            }
                            //Product Basic Source Details
                            var _basicInfoSourceDetails = companyInfocntx.spGetProductSourceDetailsByProdID(productID).ToList();
                            if (_basicInfoSourceDetails != null)
                            {
                                prdView.lstProductBasicSourceDetails = new List<SouceDetials>();
                                foreach (var _basicDataSourceDetails in _basicInfoSourceDetails)
                                {
                                    SouceDetials basicInfosource = new SouceDetials();
                                    basicInfosource.SourceTypeID = Convert.ToInt32(_basicDataSourceDetails.SourceTypeID);
                                    basicInfosource.SourceLink = _basicDataSourceDetails.SourceLink;
                                    prdView.lstProductBasicSourceDetails.Add(basicInfosource);
                                }

                            }

                            //Product Basic Indications
                            var _BasicIndications = companyInfocntx.spGetReportPrdTaxByID(productID).ToList();
                            if (_BasicIndications != null)
                            {
                                prdView.lstBasicIndications = new List<BasicIndicationDetails>();
                                foreach (var _basicDataIndications in _BasicIndications)
                                {
                                    BasicIndicationDetails basicIndications = new BasicIndicationDetails();
                                    basicIndications.IndicationNames = _basicDataIndications.IndicationNames;
                                    basicIndications.Taxonomies = _basicDataIndications.Taxonomies;
                                    basicIndications.HighestPhaseNames = _basicDataIndications.HighestPhaseNames;
                                    basicIndications.CompanyInvolvedNames = _basicDataIndications.CompanyInvolvedNames;

                                    prdView.lstBasicIndications.Add(basicIndications);
                                }
                            }
                        }
                        prdView.lsttaxonomies = GetPrdTaxonomies(productID);
                        prdView.lstCompanyInvolvement = GetPrdCompanyInvolvement(productID);
                        prdView.lstMilestones = GetMileStone(productID);
                        prdView.lstIndications = GetPhaseandTrialDetails(productID);
                    }
                    else
                    {
                        prdView.Errormsg = "Please Enter Valid Product ID";
                    }
                    return View(prdView);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }

        }
    }
}

