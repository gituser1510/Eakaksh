﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AuthoringToolDataAccess;
using AuthoringToolTaxonomies;
using System.Web.Mvc;
using PATReportView.Models;
using System.IO;
using System.Drawing;

namespace PATReportView.Controllers
{
    public class CompanyPersonController : Controller
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(CompanyPersonController));
        // GET: CompanyPerson
        public ActionResult Index()
        {
            return View();
        }
        //Person Designation Details
        public List<CompanyPersonDesignationDetails> GetPersonDesignationDetails(int CompanyId, int personManagementID)
        {

            List<CompanyPersonDesignationDetails> lst = new List<CompanyPersonDesignationDetails>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var _compPersonmanagInfoID = companyInfocntx.spGetCompanyPersonContactsLevelDetailsByCompID(CompanyId, 0).ToList();
                    var PersonManagementLevelInfoByID = _compPersonmanagInfoID.Where(p => p.CompanyPersonManagementInfoID == personManagementID).ToList();
                    if (PersonManagementLevelInfoByID != null)
                    {

                        CompanyPersonDesignationDetails objDesig = new CompanyPersonDesignationDetails();
                        foreach (var levels in PersonManagementLevelInfoByID)
                        {
                            objDesig.Department = levels.DepartmentName;
                            objDesig.IsActiveDept = Convert.ToBoolean(levels.DeptIsActive);
                            objDesig.Designation = levels.DesignationName;
                            objDesig.IsActiveDesig = Convert.ToBoolean(levels.DesgIsActive);
                            objDesig.DeptSubCategory = levels.DeptSubCategoryName;
                            objDesig.DesigSubCategory = levels.DesgSubCategoryName;
                            lst.Add(objDesig);
                        }

                    }
                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        //Person Management Info
        public List<Models.CompanyPersonManagementInfo> GetPersonManagementInfo(int CompanyId, int personManagementID)
        {

            List<Models.CompanyPersonManagementInfo> lst = new List<Models.CompanyPersonManagementInfo>();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var _compPersonmanagInfoID = companyInfocntx.spGetCompanyPersonContactsLevelDetailsByCompID(CompanyId, 0).ToList();

                    var PersonManagementInfoByID = _compPersonmanagInfoID.Where(p => p.CompanyPersonManagementInfoID == personManagementID).Distinct().FirstOrDefault();
                    if (PersonManagementInfoByID != null)
                    {

                        Models.CompanyPersonManagementInfo objMangementInfo = new Models.CompanyPersonManagementInfo();
                        objMangementInfo.Biography = PersonManagementInfoByID.Biography;
                        objMangementInfo.CompanyRelatedDesig = PersonManagementInfoByID.CompanyRelatedDesignation;
                        objMangementInfo.EmailID = PersonManagementInfoByID.EmailID;
                        objMangementInfo.FromDateMonth = Convert.ToInt32(PersonManagementInfoByID.FromDateMonth);
                        objMangementInfo.FromDateYear = Convert.ToInt32(PersonManagementInfoByID.FromDateYear);
                        objMangementInfo.LastUpdatedBy = PersonManagementInfoByID.LastUpdatedName;
                        // objMangementInfo.LastUpdatedDate = Convert.ToDateTime(PersonManagementInfoByID.LastUpdatedDate);
                        objMangementInfo.Phone = PersonManagementInfoByID.Phone;
                        objMangementInfo.CreatedBy = PersonManagementInfoByID.CreatedName;
                        if (Convert.ToDateTime(PersonManagementInfoByID.CreatedDate) != DateTime.MinValue)
                        {
                            objMangementInfo.CreatedDate = (Convert.ToDateTime(PersonManagementInfoByID.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objMangementInfo.CreatedDate = "";
                        }
                        if (Convert.ToDateTime(PersonManagementInfoByID.LastUpdatedDate) != DateTime.MinValue)
                        {
                            objMangementInfo.LastUpdatedDate = (Convert.ToDateTime(PersonManagementInfoByID.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objMangementInfo.LastUpdatedDate = "";
                        }
                        //converting comma seperated sourceURL's into array
                        string source = PersonManagementInfoByID.SourceURL;
                        if (source != null)
                        {
                            objMangementInfo.SourceURL = source.Split(',');
                        }

                        objMangementInfo.ToDateMonth = Convert.ToInt32(PersonManagementInfoByID.ToDateMonth);
                        objMangementInfo.ToDateYear = Convert.ToInt32(PersonManagementInfoByID.ToDateYear);
                        lst.Add(objMangementInfo);
                    }


                }
                return lst;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }
        public ActionResult PersonDetails(int id, int CompanyId, int personManagementID)
        {
            CompanyPersonDetails objPerson = new CompanyPersonDetails();
            try
            {
                using (var companyInfocntx = new CompanyInfoContext())
                {
                    var CompanyPersons = companyInfocntx.spGetCompanyPersonContactsByCompID(CompanyId).ToList();
                    var _PersonbyID = CompanyPersons.Where(p => p.CompanyPersonContactsID == id).SingleOrDefault();
                    if (_PersonbyID != null)
                    {
                        objPerson.Age = Convert.ToInt32(_PersonbyID.Age);
                        objPerson.CompanyReportedName = _PersonbyID.CompanyReportedName;
                        objPerson.DOBday = Convert.ToInt32(_PersonbyID.DOB_DateDay);
                        objPerson.DOBMonth = Convert.ToInt32(_PersonbyID.DOB_DateMonth);
                        objPerson.DOBYear = Convert.ToInt32(_PersonbyID.DOB_DateYear);
                        objPerson.EduQualification = _PersonbyID.EducationalQualificationsName;
                        objPerson.FirstName = _PersonbyID.FirstName;
                        objPerson.LastName = _PersonbyID.LastName;
                        objPerson.LastUpdatedBy = _PersonbyID.LastUpdatedName;
                        //objPerson.LastUpdatedDate = Convert.ToBoolean(Convert.ToDateTime(_PersonbyID.LastUpdatedDate) == DateTime.MinValue) ? _PersonbyID.LastUpdatedDate = null : Convert.ToDateTime(_PersonbyID.LastUpdatedDate);
                        objPerson.Salutation = _PersonbyID.Salutation;
                        objPerson.SocialNetwork = _PersonbyID.SocialNetworkSiteName;
                        objPerson.SocialSiteURL = _PersonbyID.SocialSiteURL;
                        objPerson.CreatedBy = _PersonbyID.CreatedName;
                        if (Convert.ToDateTime(_PersonbyID.CreatedDate) != DateTime.MinValue)
                        {
                            objPerson.CreatedDate = (Convert.ToDateTime(_PersonbyID.CreatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objPerson.CreatedDate = "";
                        }
                        if (Convert.ToDateTime(_PersonbyID.LastUpdatedDate) != DateTime.MinValue)
                        {
                            objPerson.LastUpdatedDate = (Convert.ToDateTime(_PersonbyID.LastUpdatedDate)).ToString("dd-MMM-yyyy hh:mm:ss");
                        }
                        else
                        {
                            objPerson.LastUpdatedDate = "";
                        }
                        //converting comma seperated sourceURL's into array
                        string sourceurl = _PersonbyID.SourceURL;
                        if (sourceurl != null)
                        {
                            objPerson.SourceURL = sourceurl.Split(',');
                        }

                        objPerson.SocialNetworkSiteName = _PersonbyID.SocialNetworkSiteName;
                        if (_PersonbyID.PersonPhoto != null)
                        {
                            MemoryStream ms = new MemoryStream((byte[])_PersonbyID.PersonPhoto);
                            objPerson.PersonPhoto = ms.ToArray();
                        }

                    }
                }
                objPerson.lstManagementInfo = GetPersonManagementInfo(CompanyId, personManagementID);
                objPerson.lstDesig = GetPersonDesignationDetails(CompanyId, personManagementID);
                return PartialView("_PersonDetails", objPerson);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                throw ex;
            }
        }
    }
}