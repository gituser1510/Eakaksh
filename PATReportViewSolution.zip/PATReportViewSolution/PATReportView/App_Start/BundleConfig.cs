﻿using System.Web;
using System.Web.Optimization;

namespace PATReportView
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            //bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
            //            "~/Scripts/jquery-{version}.js", "~/Scripts/jquery-ui.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));
            bundles.Add(new ScriptBundle("~/bundles/TreeView").Include(
                      "~/Scripts/TreeView.js"));
            bundles.Add(new ScriptBundle("~/bundles/Dropdown").Include(
                      "~/Scripts/Dropdown.js"));
            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));
            // Bundles for jQuery, jQueryUI and Bootstrap
            bundles.Add(new ScriptBundle("~/bundles/jQuery-v1.10.2").Include(
                    "~/Content/lib/jquery-ui-1.11.4/external/jquery/jquery.js"
                ));

            bundles.Add(new ScriptBundle("~/bundles/jQueryUI-JS-v1.11.4").Include(
                    "~/Content/lib/jquery-ui-1.11.4/jquery-ui.js"
                ));

            bundles.Add(new StyleBundle("~/bundles/jQueryUI-CSS-v1.11.4").Include(
                    "~/Content/lib/jquery-ui-1.11.4/jquery-ui.css"
                ));

            bundles.Add(new ScriptBundle("~/bundles/BootstrapJS-v3.3.6").Include(
                    "~/Content/lib/bootstrap-3.3.6-dist/js/bootstrap.js"
                ));

            bundles.Add(new StyleBundle("~/bundles/BootstrapCSS-v3.3.6").Include(
                    "~/Content/lib/bootstrap-3.3.6-dist/css/bootstrap.min.css"
                ));

            bundles.Add(new StyleBundle("~/bundles/site").Include(
                    "~/Content/Site.css"
                ));
            bundles.Add(new ScriptBundle("~/bundles/jquery.blockUI").Include(
                   "~/Scripts/jquery.blockUI.js"));
            bundles.Add(new ScriptBundle("~/bundles/jExpand").Include(
                 "~/Scripts/jExpand.js"));
            bundles.Add(new ScriptBundle("~/bundles/dashboard").Include(
                  "~/Scripts/dashboard.js"));
            bundles.Add(new ScriptBundle("~/bundles/Product").Include(
                   "~/Scripts/Product.js"));
            bundles.Add(new ScriptBundle("~/bundles/Company").Include(
                  "~/Scripts/Company.js"));


        }
    }
}
