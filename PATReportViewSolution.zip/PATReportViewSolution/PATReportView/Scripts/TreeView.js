﻿

$(document).ready(function () {
    //debugger;
    $(".tree").find("ul").hide();
    $(".expand").click(function () {
        var that = $(this).parent().find(".subItem");
        if ($(this).attr("isexpand") == "true") {
            //debugger;
            $(this).attr("src", "/Content/images/icon-expand.gif");
            that.first().hide();
            $(this).attr("isexpand", "false");
        }
        else {
            //debugger;
            $(this).attr("isexpand", "true");
            $(this).attr("src", "/Content/images/icon-collapse.gif");
            that.first().show();
        }
    })
});