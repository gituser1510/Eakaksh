﻿$(document).ready(function () {

    $("#Company").click(function () {
        $(".company").addClass('show');
        $(".btncompany").addClass('show');
    });
    $("#Product").click(function () {
        $(".product").addClass('show');
        $(".btnproduct").addClass('show');
    });
    $('#companyid').autocomplete({
        source: '@Url.Action("Search", "CompanyView")',
        minLength: 3
    })

    $('.product').autocomplete({
        source: '@Url.Action("Search", "ProductView")',
        minLength: 3
    })



})
$(function () {
    $(".btncompany").on('click', function () {
        //debugger;
        var id = $(".company").val();
        event.preventDefault();
        window.location.href = '/CompanyView/Company/' + id;
    });
    $(".btnproduct").on('click', function () {
        //debugger;
        var id = $(".product").val();
        event.preventDefault();
        window.location.href = '/ProductView/Product/' + id;
    });
})