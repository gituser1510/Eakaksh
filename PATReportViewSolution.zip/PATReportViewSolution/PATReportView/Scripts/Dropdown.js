﻿$(document).ready(function () {


    $('#dropdownid').change(function () {
        var districtId = $(this).val();
        $.ajax({
            url: '/ProductView/FillIndication',
            type: 'POST',
            data: JSON.stringify({ State: districtId }),
            dataType: 'json',
            contentType: 'application/json',
            success: function (data) {
                //debugger;
                $("#Phasefirsttable tbody").html("");
                if (data != null) {
                    $("#Phasefirsttable").show();
                    var tr = "";
                    for (var i = 0; i < data.length; i++) {

                        tr += '<tr><td>' + data[i].Name + '</td><td>   <a class="AncerEdit" SelectedId=' + data[i].Id + ' href="#">' + data[i].Name + '</a></td></tr>'
                    }


                    $("#Phasefirsttable tbody").append(tr);
                    BindChiled();
                }
            }
        });
    });




});

function BindChiled() {
    $('.AncerEdit').click(function () {
        var districtId = $(this).attr("SelectedId");
        //debugger;

        $.ajax({
            url: '/ProductView/FillTrialDates',
            type: 'POST',
            data: JSON.stringify({ State: districtId }),
            dataType: 'json',
            contentType: 'application/json',
            success: function (data) {
                $("#SecondTable tbody").html("");
                if (data != null) {
                    $("#SecondTable").show();
                    var tr = "";
                    for (var i = 0; i < data.length; i++) {

                        tr += '<tr><td>' + data[i].Name + '</td><td>   <a  SelectedId=' + data[i].Id + ' href="#">' + data[i].Name + '</a></td></tr>'
                    }

                    $("#SecondTable tbody").append(tr);
                }
            }
        });
    });
}
