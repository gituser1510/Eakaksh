﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PDB_SECFilingWinService
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                this.WriteToFile(string.Format("SEC Files Web Crawling Service starting at {0}", DateTime.Now.ToString()));
                this.ScheduleService();
            }
            catch (Exception ex)
            {
                WriteToFile(string.Format("SEC Files Web Crawling Service Error on: {0} - {1}", DateTime.Now.ToString(), ex.ToString()));
            }
        }

        protected override void OnStop()
        {
            try
            {
                this.WriteToFile(string.Format("SEC Files Web Crawling stopped at {0}", DateTime.Now.ToString()));
                this.Schedular.Dispose();
            }
            catch (Exception ex)
            {
                WriteToFile(string.Format("SEC Files Web Crawling Service Error on: {0} - {1}", DateTime.Now.ToString(), ex.ToString()));
            }
        }

        private Timer Schedular;
        public void ScheduleService()
        {
            try
            {
                Schedular = new Timer(new TimerCallback(SchedularCallback));
                string mode = ConfigurationManager.AppSettings["Mode"].ToUpper();
                this.WriteToFile(string.Format("Sec Files Web Crawling Service Mode: {0} at {1}", mode, ConfigurationManager.AppSettings["ScheduledTime"].ToUpper()));

                //Set the Default Time.
                DateTime scheduledTime = DateTime.MinValue;

                if (mode.ToUpper() == "DAILY")
                {
                    //Get the Scheduled Time from AppSettings.
                    scheduledTime = DateTime.Parse(System.Configuration.ConfigurationManager.AppSettings["ScheduledTime"]);
                    if (DateTime.Now > scheduledTime)
                    {
                        //If Scheduled Time is passed set Schedule for the next day.
                        scheduledTime = scheduledTime.AddDays(1);
                    }
                }
                else if (mode.ToUpper() == "WEEKLY")
                {
                    //Get the Scheduled Time from AppSettings.
                    scheduledTime = DateTime.Parse(System.Configuration.ConfigurationManager.AppSettings["ScheduledTime"]);
                    if (DateTime.Now > scheduledTime)
                    {
                        //If Scheduled Time is passed set Schedule for the next week same day.
                        scheduledTime = scheduledTime.AddDays(7);
                    }
                }
                else if (mode.ToUpper() == "INTERVAL")
                {
                    //Get the Interval in Minutes from AppSettings.
                    int intervalMinutes = Convert.ToInt32(ConfigurationManager.AppSettings["IntervalMinutes"]);

                    //Set the Scheduled Time by adding the Interval to Current Time.
                    scheduledTime = DateTime.Now.AddMinutes(intervalMinutes);
                    if (DateTime.Now > scheduledTime)
                    {
                        //If Scheduled Time is passed set Schedule for the next Interval.
                        scheduledTime = scheduledTime.AddMinutes(intervalMinutes);
                    }
                }

                TimeSpan timeSpan = scheduledTime.Subtract(DateTime.Now);
                string schedule = string.Format("{0} day(s) {1} hour(s) {2} minute(s) {3} seconds(s)", timeSpan.Days, timeSpan.Hours, timeSpan.Minutes, timeSpan.Seconds);

                this.WriteToFile(string.Format("SEC Files Web Crawling Service scheduled to run after: {0}", schedule));

                //Get the difference in Minutes between the Scheduled and Current Time.
                int dueTime = Convert.ToInt32(timeSpan.TotalMilliseconds);

                //Change the Timer's Due Time.
                Schedular.Change(dueTime, Timeout.Infinite);
            }
            catch (Exception ex)
            {
                WriteToFile(string.Format("SEC Files Web Crawling Service Error on: {0} - {1}", DateTime.Now.ToString(), ex.ToString()));

                //Stop the Windows Service.
                using (System.ServiceProcess.ServiceController serviceController = new System.ServiceProcess.ServiceController("PDBWebCrawlingService"))
                {
                    serviceController.Stop();

                    this.WriteToFile("SEC Files Web Crawling Service exception occured and service stopped");
                }
                this.WriteToFile("SEC Files Web Crawling service stopped");
            }
        }

        private void SchedularCallback(object e)
        {
            try
            {               
                this.WriteToFile("SEC Files Web Crawling process is starting on: " + DateTime.Now.ToString());

                //Run Web Crawling process
                bool blServStatus = CrawlSECDocs.RunSECFilesCrawlProcess(true,true);

                this.WriteToFile("SEC Files Web Crawling process completed on: " + DateTime.Now.ToString());

                this.ScheduleService();
            }
            catch (Exception ex)
            {
                WriteToFile(string.Format("SEC Files Web Crawling Service Error on: {0} - {1}", DateTime.Now.ToString(), ex.ToString()));
            }
        }

        string logFilePath = "";
        private void WriteToFile(string text)
        {
            try
            {
                logFilePath = System.Configuration.ConfigurationManager.AppSettings["LogFilePath"];
                using (StreamWriter writer = new StreamWriter(logFilePath, true))
                {
                    writer.WriteLine(string.Format(text));
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
