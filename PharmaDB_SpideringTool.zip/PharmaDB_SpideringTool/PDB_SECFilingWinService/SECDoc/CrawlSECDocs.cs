﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using System.IO;
using PDB_SECFilingWinService.DataAccess;

namespace PDB_SECFilingWinService
{
    public class CrawlSECDocs
    {
        static DateTime dateTimeVar = DateTime.Now;
        static string SecDirectoryPath = string.Empty;
        static string _fileName = string.Empty;
        static string secMainURL = "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=";
        static List<string> lstCrawlNodeTypes = null;
        static string logFileName = "";
        public static bool RunSECFilesCrawlProcess(bool saveCrawlInfoInDB, bool sendMailToSME)
        {
            bool blStatus = false;
            try
            {
                //Set Crawl service log file Name
                logFileName = System.Configuration.ConfigurationManager.AppSettings["LogFilePath"];
                string strDate = DateTime.Now.ToShortDateString().Replace("/", "_");
                strDate = "_" + strDate + ".txt";
                logFileName = logFileName.Replace(".txt", strDate);

                //Get crawl node types
                lstCrawlNodeTypes = GetCrawlNodeTypes();

                SecDirectoryPath = System.Configuration.ConfigurationManager.AppSettings["SecFileDirectoryPath"] + dateTimeVar.Month + "_" + dateTimeVar.Day + "_" + dateTimeVar.Year;
                if(!Directory.Exists(SecDirectoryPath))
                {
                    Directory.CreateDirectory(SecDirectoryPath);
                }
               
                string logVar = string.Empty;
                List<string> lstSublinks = new List<string>();
               
                using (SECDocsWebCrawlingDBContext crwlContext = new SECDocsWebCrawlingDBContext())
                {
                    List<CompanyNewsSpideringSecDocURL> lstMainUrls = (from url in crwlContext.CompanyNewsSpideringSecDocURLS
                                                                      where url.Isactive == true
                                                                     select url).ToList();

                    if (lstMainUrls != null && lstMainUrls.Count > 0)
                    {
                        string crawlUrl = string.Empty;
                        HtmlWeb web = null;
                        string maxUrl = string.Empty;
                        int? maxUrlId = null;
                        List<HtmlNode> lstFinalLinkNodes = null;

                        foreach (var companyUrl in lstMainUrls)
                        {                            
                            crawlUrl = Path.Combine(secMainURL,companyUrl.CIKCode);
                            web = new HtmlWeb();
                            lstFinalLinkNodes = new List<HtmlNode>();
                           
                            try
                            {
                                maxUrlId = (from i in crwlContext.CompanyNewsSpideringSecDocSubURLs
                                           where i.CompanySpideringSecDocURLID == companyUrl.CompanySpideringSecDocURLID 
                                              && i.Isactive == true
                                          select (int?)i.CompanNewsSpideringSecDocSubURlID).Max();

                                if (maxUrlId == null)//No crawling is done earlier
                                {
                                    lstFinalLinkNodes = FirstTimeCrawl(crawlUrl);
                                }
                                else//second time crawling
                                {
                                    HtmlAgilityPack.HtmlDocument htmlDoc = web.Load(crawlUrl);
                                    HtmlNodeCollection htmlNodeColl = htmlDoc.DocumentNode.SelectNodes("//div[@id='seriesDiv']/table/tr/td[2]");
                                    lstFinalLinkNodes = htmlNodeColl.ToList();
                                }

                                List<HtmlNode> lstLinks = new List<HtmlNode>();

                                if (lstFinalLinkNodes != null && lstFinalLinkNodes.Count > 0)
                                {
                                    foreach (HtmlNode link in lstFinalLinkNodes)
                                    {
                                        string sub = link.InnerHtml.Substring(link.InnerHtml.IndexOf("/Archive"));
                                        string subUrl = sub.Substring(0, sub.IndexOf(".htm") + 4);
                                        subUrl = Path.Combine("https://www.sec.gov", subUrl);

                                        if (maxUrlId != null && maxUrlId > 0)
                                        {
                                            maxUrl = (from i in crwlContext.CompanyNewsSpideringSecDocSubURLs
                                                     where i.CompanNewsSpideringSecDocSubURlID == maxUrlId
                                                        && i.Isactive == true
                                                    select i.SubURLName).SingleOrDefault();

                                            if (maxUrl == subUrl)
                                            {
                                                break;
                                            }
                                        }
                                        lstSublinks.Add(subUrl);                                        
                                    }

                                    if (lstSublinks.Count == 0)
                                    {                                        
                                        logVar = DateTime.Now + ": " + companyUrl.CompanyName + ": No New data is present as of now.";

                                        WriteToLogFile(logVar);
                                    }
                                    else
                                    {
                                        lstSublinks.Reverse();                                        
                                        SaveSecSubLinks(lstSublinks, companyUrl);   //Saving Sublinks to database and individual files to local disk and database.                                                       
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                logVar = DateTime.Now + ": " + companyUrl.CompanyName + ":" + ex.Message;

                                WriteToLogFile(logVar);
                            }
                        }

                        //Send mail to SME
                        if (sendMailToSME)
                        {
                            //  EmailManager.SendEmailToSME("", "", lstCrawlMailInfo);
                        }

                        //Send Log info to Development Team

                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {               
                WriteToLogFile(DateTime.Now + ":" + ex.ToString());
            }
            return blStatus;
        }

        private static List<string> GetCrawlNodeTypes()
        {
            List<string> lstNodeTypes = new List<string>();

            lstNodeTypes.Add("6-K");
            lstNodeTypes.Add("8-K");
            lstNodeTypes.Add("10-K");           
            lstNodeTypes.Add("10-Q");  
            lstNodeTypes.Add("20-F");
            lstNodeTypes.Add("40-F");
            
            lstNodeTypes.Add("DEF14");
            lstNodeTypes.Add("DEF14A");
            lstNodeTypes.Add("DEFA14A");
            lstNodeTypes.Add("DEF 14A");

            lstNodeTypes.Add("EX-10");
            lstNodeTypes.Add("EX-10.1");
            lstNodeTypes.Add("EX-10.2");

            lstNodeTypes.Add("EX-21");
            lstNodeTypes.Add("EX-21.1");

            lstNodeTypes.Add("EX-99");
            lstNodeTypes.Add("EX-99.1");
                       
            lstNodeTypes.Add("S-1");
            lstNodeTypes.Add("S-3");
            lstNodeTypes.Add("S-6");

            return lstNodeTypes;
        }

        private static List<HtmlNode> FirstTimeCrawl(string crawlUrl)
        {
            List<HtmlNode> lstLinkNodes = null;
            try
            {
                if (!string.IsNullOrEmpty(crawlUrl))
                {
                    lstLinkNodes = new List<HtmlNode>();

                    HtmlWeb web = new HtmlWeb();
                    int seedCount = 0;
                    crawlUrl = crawlUrl + "&start=";

                Step:
                    crawlUrl = crawlUrl + seedCount;
                    HtmlAgilityPack.HtmlDocument docs = web.Load(crawlUrl);
                    HtmlNodeCollection linkNodes = docs.DocumentNode.SelectNodes("//div[@id='seriesDiv']/table/tr/td[2]");
                    HtmlNodeCollection mainDateNodes = docs.DocumentNode.SelectNodes("//div[@id='seriesDiv']/table/tr/td[4]");

                    int mainCount = 0;
                    DateTime tempDate;

                    if (mainDateNodes != null && mainDateNodes.Count > 0)
                    {
                        foreach (var dateN in mainDateNodes)
                        {
                            tempDate = Convert.ToDateTime(dateN.InnerHtml);
                            if (tempDate >= Convert.ToDateTime("2016-01-01"))
                            {
                                lstLinkNodes.Add(linkNodes[mainCount]);
                            }
                            else
                            {
                                goto MainContent;
                            }
                            mainCount++;
                        }
                    }

                    seedCount += 40;
                    crawlUrl = crawlUrl.Substring(0, crawlUrl.LastIndexOf("=") + 1);

                    goto Step;

                MainContent:
                    return lstLinkNodes;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLinkNodes;
        }     
               
        private static void SaveSecSubLinks(List<string> lstSublinks, CompanyNewsSpideringSecDocURL oneUrl)
        {
            try
            {
                if (lstSublinks != null && lstSublinks.Count > 0)
                {
                    int count = 0;
                    int mainLinkCount = 0;
                    foreach (var item in lstSublinks)
                    {
                        int stat = SaveSecFiles(item, oneUrl);  // Saving individual files to local system.                
                        count += stat;
                        mainLinkCount++;
                    }

                    lstSublinks.Clear();                                       
                    
                    WriteToLogFile(DateTime.Now + ": " + oneUrl.CompanyName + ": " + count + " New url(s) added.");
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private static int SaveSecFiles(string subUri, CompanyNewsSpideringSecDocURL oneUrl)
        {
            HtmlWeb web = new HtmlWeb();
            int SublinkCount = 0;

            try
            {
                HtmlAgilityPack.HtmlDocument doc = web.Load(subUri);
                HtmlNodeCollection subNodes, typeNodes;
                string saveFilePath = string.Empty;

                #region Old code commented
                // Sometimes SEC docs have Interactive data. xPath is diffrent for such documents.
                //if (lnk.OuterHtml.IndexOf("Interactive") > 1)
                //{
                //    subNodes = doc.DocumentNode.SelectNodes("//div[@id='formDiv']/div[4]/table/tr/td[3]");
                //    typeNodes = doc.DocumentNode.SelectNodes("//div[@id='formDiv']/div[4]/table/tr/td[4]");
                //}
                //else
                //{
                //subNodes = doc.DocumentNode.SelectNodes("//div[@id='formDiv']/div[3]/table/tr/td[3]");
                //typeNodes = doc.DocumentNode.SelectNodes("//div[@id='formDiv']/div[3]/table/tr/td[4]");
                //} 
                #endregion

                subNodes = doc.DocumentNode.SelectNodes("//div[@id='formDiv']/div[3]/table/tr/td[3]");
                typeNodes = doc.DocumentNode.SelectNodes("//div[@id='formDiv']/div[3]/table/tr/td[4]");

                HtmlNode dateNode = doc.DocumentNode.SelectSingleNode("//div[@id='formDiv']/div[2]/div[1]/div[2]");

                int typeNodeCount = 0;
                bool IsSublinkSaved = false;
                int? _msg = null;

                foreach (HtmlNode fNode in subNodes)
                {
                    if (lstCrawlNodeTypes != null && lstCrawlNodeTypes.Contains(typeNodes[typeNodeCount].InnerHtml.Trim()))                        
                    {
                        if (IsSublinkSaved == false)
                        {
                            using (SECDocsWebCrawlingDBContext crwl = new SECDocsWebCrawlingDBContext())
                            {
                                var status = crwl.spInsertCompanyNewsSpideringSecDocSubURLs(0, oneUrl.CompanySpideringSecDocURLID, subUri, 1).FirstOrDefault();
                                if (status != null)
                                {
                                    _msg = status.ReturnMessage;
                                }
                                //foreach (spInsertCompanyNewsSpideringSecDocSubURLs_Result res in status)
                                //{
                                //    _msg = res.ReturnMessage;
                                //}
                            }

                            IsSublinkSaved = true;
                            SublinkCount++;
                        }

                        string partUrl = fNode.InnerHtml.Substring(fNode.InnerHtml.IndexOf("/Archive"));
                        string downloadUrl = partUrl.Substring(0, partUrl.IndexOf(">") - 1);
                        downloadUrl = Path.Combine("https://www.sec.gov", downloadUrl);

                        HtmlAgilityPack.HtmlDocument docToSave = web.Load(downloadUrl);
                        string fileName = downloadUrl.Substring(downloadUrl.LastIndexOf("/") + 1);
                        saveFilePath = Path.Combine(SecDirectoryPath, fileName);

                        docToSave.Save(saveFilePath);

                        //Saving the file to database by converting it in byte array.
                        string fileExtn = Path.GetExtension(fileName);// fileName.Substring(fileName.LastIndexOf("."));
                        using (FileStream fileStream = new FileStream(saveFilePath, FileMode.Open, FileAccess.Read))
                        {
                            using (BinaryReader br = new BinaryReader(fileStream))
                            {
                                Byte[] baFileData = br.ReadBytes((Int32)fileStream.Length);
                                string contentType = string.Empty;

                                switch (fileExtn.Trim().ToUpper())
                                {
                                    case "TXT":
                                        contentType = "text/plain";
                                        break;
                                    case "JPG":
                                        contentType = "img/jpg";
                                        break;
                                    case "PDF":
                                        contentType = "application/pdf";
                                        break;
                                    case "HTM":
                                        contentType = "text/html";
                                        break;
                                    case "XML":
                                        contentType = "text/xml";
                                        break;
                                }

                                if (!string.IsNullOrEmpty(contentType))
                                {
                                    CompanyNewsSpideringSecDocSubURLsFileName objFileNames = new CompanyNewsSpideringSecDocSubURLsFileName();
                                    objFileNames.CompanNewsSpideringSecDocSubURlFileNameID = 0;
                                    objFileNames.CompanNewsSpideringSecDocSubURlID = (Int32)_msg;
                                    objFileNames.FileName = fileName;
                                    objFileNames.FiledDate = dateNode.InnerHtml;
                                    objFileNames.FileType = typeNodes[typeNodeCount].InnerHtml;
                                    objFileNames.FileData = baFileData;
                                    objFileNames.FileContentType = contentType;
                                    objFileNames.Isactive = true;
                                    objFileNames.CreatedBy = 1;
                                    objFileNames.CreatedDate = DateTime.Now;

                                    using (SECDocsWebCrawlingDBContext ctxCrawl = new SECDocsWebCrawlingDBContext())
                                    {
                                        ctxCrawl.CompanyNewsSpideringSecDocSubURLsFileNames.Add(objFileNames);
                                        ctxCrawl.SaveChanges();
                                    }
                                    typeNodeCount++;
                                }
                                fileStream.Close();
                            }
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {                
                WriteToLogFile(DateTime.Now + "Exception occured while downloading the file. Description:" + ex.Message);
            }
            return SublinkCount;
        }
               
        private static void WriteToLogFile(string loginfo)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(logFileName, true))
                {
                    writer.WriteLine(loginfo);
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}


