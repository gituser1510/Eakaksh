﻿using HtmlAgilityPack;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using PharmaDBWebCrawlingWindowsService.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PharmaDBWebCrawlingWindowsService
{
    public static class CrawlUrl
    {
        static List<CrawlInfoBO> lstFinalCrawlInfo;
        static string logFileName = "";
        public static bool RunWebCrawlingProcess(bool saveCrawlInfoInDB, bool sendMailToSME)
        {
            bool blStatus = false;            
            try
            {
                string logFilePath = System.Configuration.ConfigurationManager.AppSettings["LogFilePath"];
                if(!Directory.Exists(logFilePath))
                {
                    Directory.CreateDirectory(logFilePath);
                }

                //Set Crawl service log file Name
                logFileName = System.Configuration.ConfigurationManager.AppSettings["LogFileName"];
                string strDate = DateTime.Now.ToShortDateString().Replace("/", "_");
                strDate = "_" + strDate + ".txt";
                logFileName = System.IO.Path.Combine(logFilePath,logFileName.Replace(".txt", strDate));

                //Get Companies details from DB
                List<CompanyNewsSpideringURL> lstSpdrURLs = GetCompaniesSpiderUrls();
                if (lstSpdrURLs != null && lstSpdrURLs.Any())
                {
                    int compScrpUrlID = 0;
                    int spiderSubLinkID = 0;
                    HtmlWeb hw;
                    HtmlAgilityPack.HtmlDocument hDoc;
                                        
                    List<CrawlMailInfoBO> lstCrawlMailInfo = new List<CrawlMailInfoBO>();

                    if(!Directory.Exists(@"D:\CrawlCompanies"))
                    {
                        Directory.CreateDirectory(@"D:\CrawlCompanies");
                    }

                    hw = new HtmlWeb();
                    hw.UsingCache = false;
                            
                    string userName = System.Configuration.ConfigurationManager.AppSettings["UserName"];
                    string userPassword = System.Configuration.ConfigurationManager.AppSettings["Password"];
                    string proxyServer = System.Configuration.ConfigurationManager.AppSettings["ProxyServer"];

                    foreach (var spdrUrl in lstSpdrURLs)
                    {
                        try
                        {
                            lstFinalCrawlInfo = new List<CrawlInfoBO>();

                            lstUniquePages.Clear();

                            //Write company info to file
                            WriteToLogFile("Web Crawling started for the Company ID: " + spdrUrl.CompanyID + " - Company Name: " + spdrUrl.CompanyName.Trim() + " - on " + DateTime.Now.ToString());

                            //Company scrape urlID
                            compScrpUrlID = spdrUrl.CompanyScrapeURLsID;

                            //Get saved sub links for comparison at once, for avoiding repeated DB hit for comparision

                            //Get Max scrapeUrlID
                            spiderSubLinkID = GetMaxSpiderSubLinkUrlIDOnSpiderUrlID(compScrpUrlID);
                                                        
                            //hw = new HtmlWeb();
                            //hw.UsingCache = false;

                            hDoc = hw.Load(spdrUrl.CompanyScrapeURLs.Trim(), proxyServer, 8080, userName, userPassword);
                            //hDoc = hw.Load(spdrUrl.CompanyScrapeURLs.Trim());

                            File.WriteAllText(@"D:\CrawlCompanies\" + spdrUrl.CompanyID + ".txt", hDoc.DocumentNode.InnerHtml);

                            //Check Year wise pagination for crawling
                            if (!string.IsNullOrEmpty(spdrUrl.YearXpath))
                            {
                                HtmlNodeCollection hncYearWise = hDoc.DocumentNode.SelectNodes(spdrUrl.YearXpath.Trim());
                                List<CrawlInfoBO> lstCrwlInfoYear = GetYearWisePaginationCrawlInfoFromHtmlNodeCollection(hncYearWise, spdrUrl.CompanyScrapeURLsID, spdrUrl.CompanyScrapeURLs.Trim(), spdrUrl.URLXpath, spdrUrl.ContentXpath, spdrUrl.TitleXpath, spdrUrl.PublishedDateXpath, (Int32)spdrUrl.CompanyID, spdrUrl.CompanyName);
                                if (lstCrwlInfoYear != null && lstCrwlInfoYear.Any())
                                {
                                    lstFinalCrawlInfo.AddRange(lstCrwlInfoYear.Where(x => !lstFinalCrawlInfo.Any(y => y.ScrapeUrl == x.ScrapeUrl)));
                                }
                            }

                            //Get Crawled data from the url
                            List<CrawlInfoBO> lstCompCrwlInfo = GetCrawlInfoFromHtmlDocument(hDoc, spdrUrl.CompanyScrapeURLsID, spdrUrl.CompanyScrapeURLs.Trim(), spdrUrl.URLXpath, spdrUrl.ContentXpath, spdrUrl.TitleXpath, spdrUrl.PublishedDateXpath, (Int32)spdrUrl.CompanyID, spdrUrl.CompanyName);
                            if (lstCompCrwlInfo != null && lstCompCrwlInfo.Any())
                            {
                                lstFinalCrawlInfo.AddRange(lstCompCrwlInfo.Where(x => !lstFinalCrawlInfo.Any(y => y.ScrapeUrl == x.ScrapeUrl)));
                            }

                            //Get Paginated Crawled data 
                            if (!string.IsNullOrEmpty(spdrUrl.PaginationXpath) && !spdrUrl.PaginationXpath.Trim().Contains("DUMMYPAGINATION"))
                            {
                                HtmlNodeCollection hncPaginated = hDoc.DocumentNode.SelectNodes(spdrUrl.PaginationXpath.Trim());
                                HtmlNodeCollection hncPubDateXPaths = hDoc.DocumentNode.SelectNodes(spdrUrl.PublishedDateXpath.Trim());

                                if (hncPaginated != null && hncPaginated.Any())
                                {
                                    List<CrawlInfoBO> lstCrwlInfo_Paginated = GetPaginationCrawlInfoFromHtmlNodeCollection(spdrUrl.PaginationXpath.Trim(), hncPaginated, hncPubDateXPaths, spdrUrl.CompanyScrapeURLsID, spdrUrl.CompanyScrapeURLs.Trim(), spdrUrl.URLXpath, spdrUrl.ContentXpath, spdrUrl.TitleXpath, spdrUrl.PublishedDateXpath, (Int32)spdrUrl.CompanyID, spdrUrl.CompanyName);

                                    if (lstCrwlInfo_Paginated != null && lstCrwlInfo_Paginated.Any())
                                    {
                                        lstFinalCrawlInfo.AddRange(lstCrwlInfo_Paginated.Where(x => !lstFinalCrawlInfo.Any(y => y.ScrapeUrl == x.ScrapeUrl)));
                                    }
                                }

                                //Get Year wise pagination crawled data
                                if (hncPubDateXPaths != null && hncPubDateXPaths.Any())
                                {
                                    int yearPagingCnt = hncPubDateXPaths.Select(x => x.Descendants("a")).Count();
                                    if (yearPagingCnt > 0)
                                    {
                                        List<CrawlInfoBO> lstCrwlInfoYear = GetYearWisePaginationCrawlInfoFromHtmlNodeCollection(hncPaginated, spdrUrl.CompanyScrapeURLsID, spdrUrl.CompanyScrapeURLs.Trim(), spdrUrl.URLXpath, spdrUrl.ContentXpath, spdrUrl.TitleXpath, spdrUrl.PublishedDateXpath, (Int32)spdrUrl.CompanyID, spdrUrl.CompanyName);
                                        if (lstCrwlInfoYear != null && lstCrwlInfoYear.Any())
                                        {
                                            lstFinalCrawlInfo.AddRange(lstCrwlInfoYear.Where(x => !lstFinalCrawlInfo.Any(y => y.ScrapeUrl == x.ScrapeUrl)));
                                        }
                                    }
                                }
                            }                            
                            
                            //Save company total crawl info to DB
                            if (lstFinalCrawlInfo != null && lstFinalCrawlInfo.Any())
                            {
                                //Reverse the list after regular crawling and pagination, to save the latest url data at last
                                lstFinalCrawlInfo.Reverse();

                                if (saveCrawlInfoInDB)//Check the DB save status
                                {
                                    //Save crawled info in DB
                                    if (SaveCrawlInfoInDatabase(lstFinalCrawlInfo, compScrpUrlID))
                                    {
                                        //Add Crawl info to Mail info list
                                        lstCrawlMailInfo.Add(new CrawlMailInfoBO() { CompanyID = lstFinalCrawlInfo[0].CompanyID, CompanyName = lstFinalCrawlInfo[0].CompanyName, NoOfUpdates = lstFinalCrawlInfo.Count });

                                        //Write crawl info to log file
                                        WriteToLogFile(string.Format("Web crawling completed. CompanyID: {0} -- Company Name: {1} -- No.of Updates {2} -- on Date: {3}", lstFinalCrawlInfo[0].CompanyID, lstFinalCrawlInfo[0].CompanyName.Trim(), lstFinalCrawlInfo.Count, DateTime.Now.ToString()));

                                        //Write crawl completed time to log file
                                        //WriteToLogFile(string.Format("Web crawling completed for CompanyID: {0} - Company Name: {1} - on {2}", lstFinalCrawlInfo[0].CompanyID, lstFinalCrawlInfo[0].CompanyName.Trim(), DateTime.Now.ToString()));
                                    }
                                    else
                                    {
                                        WriteToLogFile(string.Format("Web crawling failed and not saved in database. CompanyID: {0} -- Company Name: {1} -- No.of Updates {2} -- on Date: {3}", lstFinalCrawlInfo[0].CompanyID, lstFinalCrawlInfo[0].CompanyName.Trim(), lstFinalCrawlInfo.Count, DateTime.Now.ToString()));
                                    }
                                }
                            }
                            else//No updates for the company
                            {
                                WriteToLogFile(string.Format("Web crawling completed. CompanyID: {0} -- Company Name: {1} -- No.of Updates {2} -- on Date: {3}", spdrUrl.CompanyID, spdrUrl.CompanyName.Trim(), "0", DateTime.Now.ToString()));
                            }

                            //if (myProcess != null)
                            //{
                            //    // myProcess process by sending a close message to its main window.
                            //    myProcess.CloseMainWindow();
                            //    // Free resources associated with process.
                            //    myProcess.Close();
                            //}
                        }
                        catch (Exception ex)
                        {
                            WriteToLogFile(string.Format("Web Crawling Error on {0} - {1}", DateTime.Now.ToString(), ex.ToString()));
                        }
                    }

                    //Send mail to SME
                    if (sendMailToSME && lstCrawlMailInfo.Any())
                    {
                        //  EmailManager.SendEmailToSME("", "", lstCrawlMailInfo);
                    }

                    //Send Log info to Development Team

                    blStatus = true;
                }
            }
            catch (Exception ex)
            {
                WriteToLogFile(string.Format("Web Crawling Error on {0} - {1}", DateTime.Now.ToString(), ex.ToString()));                
            }
            return blStatus;
        }

        private static List<CompanyNewsSpideringURL> GetCompaniesSpiderUrls()
        {
            List<CompanyNewsSpideringURL> lstSpiderUrls = null;
            try
            {
                using (WebCrawlingDBContext crlfilContext = new WebCrawlingDBContext())
                {
                    lstSpiderUrls = (from spidURLS in crlfilContext.CompanyNewsSpideringURLs
                                     orderby spidURLS.CompanyScrapeURLsID descending
                                     select spidURLS).ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return lstSpiderUrls;
        }

        private static int GetMaxSpiderSubLinkUrlIDOnSpiderUrlID(int spiderUrlID)
        {
            int spiderSublinkID = 0;
            try
            {
                using (WebCrawlingDBContext crlfilContext = new WebCrawlingDBContext())
                {
                    spiderSublinkID = (from spidURLS in crlfilContext.CompanyNewsSpideringSubLinks
                                       where spidURLS.CompanyScrapeURLsID == spiderUrlID
                                       select spidURLS).Count();

                    if (spiderSublinkID > 0)
                    {
                        spiderSublinkID = (from spidURLS in crlfilContext.CompanyNewsSpideringSubLinks
                                           where spidURLS.CompanyScrapeURLsID == spiderUrlID
                                           select spidURLS.CompanyNewsSpidiringSubLinkID).Max();

                        //spiderSublinkID = (from d in (from spidURLS in crlfilContext.CompanyNewsSpideringSubLinks
                        //                              where spidURLS.CompanyScrapeURLsID == spiderUrlID
                        //                              select spidURLS)
                        //                   where d != null
                        //                   select d.CompanyNewsSpidiringSubLinkID).Max();
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return spiderSublinkID;
        }

        private static List<CrawlInfoBO> GetCrawlInfoFromHtmlDocument(HtmlDocument hDoc, int scrapeUrlID, string rootUrl, string urlXPath, string contentXPath, string titleXPath, string pubDateXPath, int companyID, string companyName)
        {
            List<CrawlInfoBO> lstCrawlInfo = null;
            try
            {
                if (hDoc != null)
                {
                    HtmlNodeCollection hncUrlXpaths = hDoc.DocumentNode.SelectNodes(urlXPath.Trim());
                    HtmlNodeCollection hncPubDateXPaths = hDoc.DocumentNode.SelectNodes(pubDateXPath.Trim());
                    if (hncUrlXpaths != null && hncUrlXpaths.Any())
                    {
                        bool breakStatus = false;
                        lstCrawlInfo = GetCrawlInfoFromHtmlNodeCollection(hDoc, hncUrlXpaths, hncPubDateXPaths, scrapeUrlID, rootUrl, urlXPath, contentXPath, titleXPath, pubDateXPath, companyID, companyName, out breakStatus);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCrawlInfo;
        }

        private static List<CrawlInfoBO> GetCrawlInfoFromHtmlNodeCollection(HtmlAgilityPack.HtmlDocument hDoc, HtmlNodeCollection hncUrlXpaths, HtmlNodeCollection publishDateXPaths, 
                                                                            int scrapeUrlID, string rootUrl, string urlXPath, string contentXPath, string titleXPath, 
                                                                            string dateXPath, int companyID, string companyName, out bool breakStatus)
        {
            List<CrawlInfoBO> lstCrawlInfo = null;
            bool blBreakStatus = false;
            try
            {
                if (hncUrlXpaths != null && hncUrlXpaths.Any())
                {
                    lstCrawlInfo = new List<CrawlInfoBO>();

                    string resultUrl = string.Empty;
                    string headerContent = string.Empty;
                    string urlContent = string.Empty;
                    int statusCode = 0;
                    bool pdfExtn = false;

                    //Add root url to unique list
                    lstUniquePages.Add(rootUrl);

                    int nodeIndx = -1;
                    foreach (HtmlNode hnode in hncUrlXpaths)
                    {
                        try
                        {
                            //Check pagination links for handling Next - Last type pagination and avoiding duplicate page links
                            nodeIndx++;

                            #region MyRegion
                            //if (hnode.Name == "a" && hnode.HasAttributes)//Page link will be in <a> tag
                            //{
                            //   //string hrefAttrbValue = hnode.GetAttributeValue("href", "");

                            //    strPageUrl = hnode.GetAttributeValue("href", "");

                            //    if (!string.IsNullOrEmpty(strPageUrl.Trim()) && strPageUrl != rootUrl)
                            //    {
                            //        if (lstUniquePages != null)
                            //        {
                            //            if (!lstUniquePages.Contains(strPageUrl))
                            //            {
                            //                lstUniquePages.Add(strPageUrl);
                            //            }
                            //            else
                            //            {
                            //                break;
                            //            }
                            //        }
                            //    }
                            //    else
                            //    {
                            //        break;
                            //    }
                            //}
                            //else
                            //{
                            //    //Do nothing
                            //} 
                            #endregion

                            //Clear the variables
                            resultUrl = "";
                            headerContent = "";
                            urlContent = "";

                            //Get Result url from htmlnode
                            resultUrl = GetResultUrlFromNode(hnode, rootUrl);

                            //Get Result url response code
                            statusCode = GetResultUrlWebResponseStatusCode(resultUrl);

                            //Check pdf extn in result url
                            pdfExtn = resultUrl.ToUpper().IndexOf(".PDF") > 0 ? true : false;

                            //Get url content from the result url                      
                            urlContent = GetHeaderAndTextContentFromResultUrl(resultUrl, statusCode, pdfExtn, titleXPath, contentXPath, out headerContent);

                            //Check the header content in the database, if not exist then add the record to list else break
                            if (!CheckSubLinkUrlExistInDatabase(resultUrl, scrapeUrlID))
                            {
                                //Add to Crawl object
                                CrawlInfoBO objCrawl = new CrawlInfoBO();
                                objCrawl.CompanyID = companyID;
                                objCrawl.CompanyName = companyName.Trim();
                                objCrawl.NewsContent = urlContent;
                                objCrawl.HeaderContent = RemoveSpacesInString(headerContent);
                                objCrawl.ScrapeUrl = RemoveSpacesInString(resultUrl);
                                objCrawl.ScrapeUrlID = scrapeUrlID;
                                objCrawl.PublishedDate = GetPublicationDateForUrl(publishDateXPaths, nodeIndx, hncUrlXpaths.Count, hnode, dateXPath);


                                if (!lstFinalCrawlInfo.Any(x => x.ScrapeUrl == objCrawl.ScrapeUrl))//Check in the Final list
                                {
                                    if (!lstCrawlInfo.Any(x => x.ScrapeUrl == objCrawl.ScrapeUrl))
                                    {
                                        //Add to list
                                        lstCrawlInfo.Add(objCrawl);
                                    }
                                    else
                                    {
                                        blBreakStatus = true;
                                        break;//Url already crawlled, so skip all the remaining urls from this url
                                    }
                                }
                                else
                                {
                                    blBreakStatus = true;
                                    break;
                                }
                            }
                            else
                            {
                                blBreakStatus = true;
                                break;//Url already crawlled, so skip all the remaining urls from this url
                            }
                        }
                        catch
                        {
                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            breakStatus = blBreakStatus;
            return lstCrawlInfo;
        }

        //Store unique pages in a list
        static List<string> lstUniquePages = new List<string>();
        private static List<CrawlInfoBO> GetPaginationCrawlInfoFromHtmlNodeCollection(string paginationXPath, HtmlNodeCollection hncPageUrlXpaths, HtmlNodeCollection publishDateXPaths, int scrapeUrlID, string rootUrl, string urlXPath, string contentXPath, string titleXPath, string dateXPath, int companyID, string companyName)
        {
            List<CrawlInfoBO> lstCrawlInfo = null;
            try
            {
                if (hncPageUrlXpaths != null && hncPageUrlXpaths.Any())
                {
                    lstCrawlInfo = new List<CrawlInfoBO>();

                    string resultUrl = string.Empty;
                    string headerContent = string.Empty;
                    string urlContent = string.Empty;

                    HtmlAgilityPack.HtmlWeb objHtmlWeb = new HtmlWeb();
                    HtmlAgilityPack.HtmlDocument hpageDoc = new HtmlDocument();

                    //Add root url to unique list
                    if (!lstUniquePages.Contains(rootUrl))
                        lstUniquePages.Add(rootUrl);

                    string strPageUrl = "";
                    int nodeIndx = -1;
                    HtmlNodeCollection pageNodeColl = hncPageUrlXpaths;

                  step:
                    foreach (HtmlNode pageHnode in pageNodeColl)
                    {
                        try
                        {
                            //Check pagination links for handling Next - Last type pagination and avoiding duplicate page links
                            nodeIndx++;

                            if (pageHnode.Name == "a" && pageHnode.HasAttributes)//Page link will be in <a> tag
                            {
                                strPageUrl = pageHnode.GetAttributeValue("href", "");

                                if (!string.IsNullOrEmpty(strPageUrl.Trim()) && strPageUrl != rootUrl)
                                {
                                    if (!lstUniquePages.Contains(strPageUrl))
                                    {
                                        lstUniquePages.Add(strPageUrl);
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                                else
                                {
                                    break;
                                }
                            }
                            else
                            {
                                //Do nothing
                            }
                            if (!string.IsNullOrEmpty(strPageUrl.Trim()))
                            {
                                //Uri baseUri = new Uri(rootUrl);
                                Uri myUri = new Uri(new Uri(rootUrl), strPageUrl);
                                var res_PaginatedUrl = myUri.ToString();
                                string pageFinalUrl = WebUtility.HtmlDecode(res_PaginatedUrl);
                                hpageDoc = objHtmlWeb.Load(pageFinalUrl);//, "192.168.114.204", 8080, "sairamp", "apple@123");

                                HtmlNodeCollection hncPageHRef = hpageDoc.DocumentNode.SelectNodes(urlXPath.Trim());
                                HtmlNodeCollection hncPagePublishDate = hpageDoc.DocumentNode.SelectNodes(dateXPath.Trim());

                                #region MyRegion
                                ////Get Result url response code
                                //statusCode = GetResultUrlWebResponseStatusCode(pageFinalUrl);

                                ////Check pdf extn in result url
                                //pdfExtn = resultUrl.ToUpper().IndexOf(".PDF") > 0 ? true : false;

                                ////Get url content from the result url                      
                                //urlContent = GetHeaderAndTextContentFromResultUrl(resultUrl, statusCode, pdfExtn, titleXPath, contentXPath, out headerContent);

                                ////Check the header content in the database, if not exist then add the record to list else break
                                //if (!CheckSubLinkUrlExistInDatabase(resultUrl, scrapeUrlID))
                                //{
                                //    //Add to Crawl object
                                //    CrawlInfoBO objCrawl = new CrawlInfoBO();
                                //    objCrawl.CompanyID = companyID;
                                //    objCrawl.CompanyName = companyName;
                                //    objCrawl.NewsContent = urlContent;
                                //    objCrawl.HeaderContent = RemoveSpacesInString(headerContent);
                                //    objCrawl.ScrapeUrl = RemoveSpacesInString(resultUrl);
                                //    objCrawl.ScrapeUrlID = scrapeUrlID;
                                //    objCrawl.PublishedDate = GetPublicationDateForUrl(publishDateXPaths, nodeIndx, hncPageUrlXpaths.Count, pageHnode, dateXPath);

                                //    //Add to list
                                //    lstCrawlInfo.Add(objCrawl);
                                //}
                                //else
                                //{
                                //    break;//Url already crawlled, so skip all the remaining urls from this url
                                //} 
                                #endregion

                                if (hncPageHRef != null && hncPageHRef.Any())
                                {
                                    bool breakStatus = false;
                                    List<CrawlInfoBO> crwlList = GetCrawlInfoFromHtmlNodeCollection(hpageDoc, hncPageHRef, hncPagePublishDate, scrapeUrlID, rootUrl, urlXPath, contentXPath, titleXPath, dateXPath, companyID, companyName, out breakStatus);
                                    if (!breakStatus)
                                    {
                                        int cnt = crwlList.Where(x => !lstCrawlInfo.Any(y => y.ScrapeUrl == x.ScrapeUrl)).Count();
                                        if (cnt > 0)
                                        {
                                            if (crwlList != null && crwlList.Count > 0)
                                            {
                                                lstCrawlInfo.AddRange(crwlList);
                                            }
                                        }
                                        else
                                        {
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        break;
                                    }
                                    //}

                                    //Check if page links exist
                                    //HtmlAgilityPack.HtmlWeb objHtml = new HtmlWeb();
                                    hpageDoc = objHtmlWeb.Load(pageFinalUrl);//, "192.168.114.204", 8080, "sairamp", "apple@123");
                                    pageNodeColl = hpageDoc.DocumentNode.SelectNodes("." + paginationXPath.Trim());
                                    if (pageNodeColl != null)
                                    {
                                        goto step;
                                    }
                                }
                            }
                        }
                        catch 
                        {
                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCrawlInfo;
        }

        private static List<CrawlInfoBO> GetYearWisePaginationCrawlInfoFromHtmlNodeCollection(HtmlNodeCollection hncYearWiseXpaths, int scrapeUrlID, string rootUrl, string urlXPath, string contentXPath, string titleXPath, string dateXPath, int companyID, string companyName)
        {
            List<CrawlInfoBO> lstCrawlInfo = null;
            try
            {
                if (hncYearWiseXpaths!= null && hncYearWiseXpaths.Any())
                {
                    lstCrawlInfo = new List<CrawlInfoBO>();

                    string resultUrl = string.Empty;
                    string headerContent = string.Empty;
                    string urlContent = string.Empty;

                    HtmlNodeCollection pageNodeColl = hncYearWiseXpaths;
                    string paginatedLink = "";
                    foreach (HtmlNode yearwise in pageNodeColl)
                    {
                        try
                        {
                            if (yearwise.Name != "a" && yearwise.Descendants("a").Count() > 0)
                            {
                                HtmlNodeCollection hncYearWisePaginated = yearwise.SelectNodes(".//a");

                                if (hncYearWisePaginated != null && hncYearWisePaginated.Any())
                                {
                                    HtmlWeb objHtmlWeb = null;
                                    HtmlAgilityPack.HtmlDocument pageHtmlDoc = null;

                                    foreach (HtmlNode hnPage in hncYearWisePaginated)
                                    {
                                        paginatedLink = hnPage.Name == "a" ? hnPage.Attributes["href"].Value : "";

                                        //if (hnPage.InnerText.Contains("2015"))//Get Crawl info from 2015 or later only
                                        //{                                        
                                        Uri myUri = new Uri(new Uri(rootUrl), paginatedLink);
                                        var res_Url = myUri.ToString();
                                        res_Url = WebUtility.HtmlDecode(res_Url);

                                        objHtmlWeb = new HtmlWeb();
                                        pageHtmlDoc = objHtmlWeb.Load(res_Url);//, "192.168.114.204", 8080, "sairamp", "apple@123");

                                        HtmlNodeCollection hrefs1 = pageHtmlDoc.DocumentNode.SelectNodes(urlXPath.Trim());
                                        HtmlNodeCollection newsPublishedDate1 = pageHtmlDoc.DocumentNode.SelectNodes(dateXPath.Trim());

                                        bool breakStatus = false;
                                        List<CrawlInfoBO> lstPageCrwlInfo = GetCrawlInfoFromHtmlNodeCollection(pageHtmlDoc, hrefs1, newsPublishedDate1, scrapeUrlID, rootUrl, urlXPath.Trim(), contentXPath, titleXPath, dateXPath, companyID, companyName, out breakStatus);
                                        if (!breakStatus)
                                        {
                                            int cnt = lstPageCrwlInfo.Where(x => !lstCrawlInfo.Any(y => y.ScrapeUrl == x.ScrapeUrl)).Count();
                                            if (cnt > 0)
                                            {
                                                if (lstPageCrwlInfo != null && lstPageCrwlInfo.Any())
                                                {
                                                    lstCrawlInfo.AddRange(lstPageCrwlInfo);
                                                }
                                            }
                                            else
                                            {
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            break;
                                        }
                                        //}
                                    }
                                }
                            }
                        }
                        catch 
                        {
                           
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            return lstCrawlInfo;
        }

        private static string GetResultUrlFromNode(HtmlNode hNode, string rootUrl)
        {
            string resultUrl = "";
            try
            {
                if (hNode != null && !string.IsNullOrEmpty(rootUrl))
                {
                    string tempUrl = "";

                    if (hNode.Name == "a")
                    {
                        tempUrl = hNode.GetAttributeValue("href", "");
                    }
                    else if (hNode.Descendants("a").Count() > 0)
                    {
                        tempUrl = hNode.SelectSingleNode(".//a").GetAttributeValue("href", "");
                    }

                    //Uri baseUri = new Uri(rootUrl);
                    //Uri myUri = new Uri(baseUri, tempUrl);
                    //string res_Url = WebUtility.HtmlDecode(myUri.ToString()).ToString();                   

                    resultUrl = WebUtility.HtmlDecode(new Uri(new Uri(rootUrl), tempUrl).ToString()).ToString();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return resultUrl;
        }

        private static int GetResultUrlWebResponseStatusCode(string resultUrl)
        {
            int statusCode = 0;
            try
            {
                HttpWebRequest myHttpWebRequest = (HttpWebRequest)WebRequest.Create(resultUrl);
                myHttpWebRequest.MaximumAutomaticRedirections = 1;
                myHttpWebRequest.AllowAutoRedirect = true;
                using (HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse())
                {
                    statusCode = (int)myHttpWebResponse.StatusCode;
                }
            }
            catch (WebException ex)
            {
                if (ex.Message.Contains("(404) Not Found"))
                {
                    statusCode = 404;
                }
            }
            return statusCode;
        }

        private static string GetHeaderAndTextContentFromResultUrl(string resultUrl, int statusCode, bool pdfExtn, string titleXPath, string contentXPath, out string headerContent_Out)
        {
            string textContent = "";
            string headerContent = "";
            try
            {
                if (!string.IsNullOrEmpty(resultUrl))
                {
                    using (var wc = new WebClient())
                    {
                        if (statusCode == 200 && !pdfExtn)
                        {
                            HtmlAgilityPack.HtmlDocument contentDoc = new HtmlDocument();
                            contentDoc.LoadHtml(wc.DownloadString(resultUrl));

                            HtmlNodeCollection titleNodes = contentDoc.DocumentNode.SelectNodes(titleXPath.Trim());
                            if (titleNodes != null)
                            {
                                foreach (HtmlNode titlecontent in titleNodes)
                                {
                                    headerContent = headerContent.Trim() + titlecontent.SelectSingleNode(titleXPath.Trim()).InnerText + Environment.NewLine;
                                }
                            }
                            else
                            {
                                headerContent = "No Header Text Found for this Link";
                            }

                            HtmlNodeCollection contentNodes = contentDoc.DocumentNode.SelectNodes(contentXPath.Trim());
                            if (contentNodes != null)
                            {
                                foreach (HtmlNode content in contentNodes)
                                {
                                    textContent = textContent + content.SelectSingleNode(contentXPath.Trim()).InnerHtml + Environment.NewLine;
                                }
                            }
                            else
                            {
                                textContent = "No Content Found for the Entered ContentXath...try with Correct ContentXpath";
                            }
                        }
                        else if (statusCode == 200 && pdfExtn)
                        {
                            textContent = ExtractTextFromPdf(resultUrl);
                        }
                        else if (statusCode == 301)//Redirection url
                        {
                            textContent = resultUrl;
                        }
                        else if (statusCode == 404)//Page not found
                        {
                            textContent = "Page not found";
                        }
                        else//blank
                        {
                            textContent = "No Content Found for the Entered ContentXath...try with Correct ContentXpath";
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            headerContent_Out = headerContent;
            return textContent;
        }

        private static bool CheckSubLinkUrlExistInDatabase(string subLinkUrl, int spiderUrlID)
        {
            bool blStatus = false;
            try
            {
                using (WebCrawlingDBContext ctxSpideringInsert = new WebCrawlingDBContext())
                {
                    var spdrs = (from spidURLS in ctxSpideringInsert.CompanyNewsSpideringSubLinks
                                 where spidURLS.CompanyScrapeURLsID == spiderUrlID
                                   && spidURLS.NewsURL == subLinkUrl
                                 select spidURLS).Count();

                    if (spdrs > 0)
                    {
                        blStatus = true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blStatus;
        }

        private static string GetPublicationDateForUrl(HtmlNodeCollection newsPublishedDate, int spiderUrlIndex, int spiderUrlsCount, HtmlNode href, string pubDateXpath)
        {
            string publicationDate = "";
            try
            {
                if (newsPublishedDate != null && newsPublishedDate.Any())
                {
                    if (newsPublishedDate.Count >= spiderUrlsCount)
                    {
                        publicationDate = newsPublishedDate.ElementAt(spiderUrlIndex).InnerText ?? "";
                    }
                    else
                    {
                        var ele = href.SelectSingleNode("." + pubDateXpath.Trim());
                        if (ele != null)
                        {
                            publicationDate = href.SelectSingleNode("." + pubDateXpath.Trim()).InnerText;
                        }
                        else
                        {
                            publicationDate = "No Date Found for the SubLink";
                        }
                    }

                    //Remove extra spaces
                    publicationDate = RemoveSpacesInString(publicationDate);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return publicationDate;
        }

        private static string RemoveSpacesInString(string input)
        {
            string output = input.Trim();
            try
            {
                output = Regex.Replace(input, @"\s+", " ");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return output;
        }

        private static string ExtractTextFromPdf(string path)
        {
            try
            {
                using (PdfReader reader = new PdfReader(path))
                {
                    string pdfContent = string.Empty;

                    for (int i = 1; i <= reader.NumberOfPages; i++)
                    {
                        pdfContent = pdfContent + PdfTextExtractor.GetTextFromPage(reader, i) + Environment.NewLine;
                    }

                    return pdfContent.ToString();
                }
            }
            catch (Exception ex)
            {
                var logVarpdf = DateTime.Now + ":" + "Exception in pdf section" + ":" + ex.Message;
                //objLogFile.WriteToFile(logVarpdf);
                return logVarpdf;
            }

        }

        private static bool SaveCrawlInfoInDatabase(List<CrawlInfoBO> crawlInfoList, int spiderId)
        {
            bool blStatus = false;
            try
            {
                using (WebCrawlingDBContext ctxSpideringInsert = new WebCrawlingDBContext())
                {                   
                    var dt = new DataTable();
                    dt.Columns.Add("CompanyScrapUrlID");
                    dt.Columns.Add("NewsHeadLines");
                    dt.Columns.Add("NewsUrl");
                    dt.Columns.Add("NewsContent");
                    dt.Columns.Add("NewsPublishedDate");

                    foreach (CrawlInfoBO cinfo in crawlInfoList)
                    {
                        dt.Rows.Add(cinfo.ScrapeUrlID, cinfo.HeaderContent, cinfo.ScrapeUrl, cinfo.NewsContent, cinfo.PublishedDate);
                    }

                    var paramTable = new System.Data.SqlClient.SqlParameter("Paramtable", SqlDbType.Structured);
                    paramTable.Value = dt;
                    paramTable.TypeName = "dbo.CrawlInfoType";
                    ctxSpideringInsert.ExecuteStoredProcedure("spInsertCompanyNewsSpideringSecDocSubURLs_New", paramTable);

                    blStatus = true;
                    #region MyRegion
                    //foreach (CrawlInfoBO crwlInfo in crawlInfoList)
                    //{                       
                    //    var spideringSaving = ctxSpideringInsert.spInsertUpdateCompanyNewsSpideringSubLinks(0, spiderId, crwlInfo.HeaderContent, crwlInfo.ScrapeUrl, crwlInfo.NewsContent, crwlInfo.PublishedDate, 1);

                    //    if (spideringSaving != null)
                    //    {
                    //        //foreach (spInsertUpdateCompanyNewsSpideringSubLinks_Result res in spideringSaving)
                    //        //{
                    //        //    if (res.CompanyNewsSpidiringSubLinkID > 0)
                    //        //    {
                    //        //        int subspiderId = int.Parse(res.CompanyNewsSpidiringSubLinkID.ToString());
                    //        //        _returnMsg = res.ReturnMessage;
                    //        //    }
                    //        //}
                    //        blStatus = true;
                    //    }
                    //} 
                    #endregion
                }
            }
            catch// (Exception ex)
            {
               // throw ex;
            }
            return blStatus;
        }       

        public static DataSet GetResults()
        {
            DataSet ds = null;
            using (WebCrawlingDBContext ctxSpideringInsert = new WebCrawlingDBContext())
            {
                ds = ctxSpideringInsert.GetResultFromProcedure();
            }
            return ds;
        }

        static string logFilePath = "";
        private static void WriteToLogFile(string loginfo)
        {
            try
            {                
                using (StreamWriter writer = new StreamWriter(logFileName, true))
                {
                    writer.WriteLine(loginfo);
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
