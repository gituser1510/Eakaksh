﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmaDBWebCrawlingWindowsService
{
    public class CrawlInfoBO
    {
        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
        public int ScrapeUrlID { get; set; }
        public string ScrapeUrl { get; set; }
        public string HeaderContent { get; set; }
        public string NewsContent { get; set; }
        public string PublishedDate { get; set; }
    }
}
