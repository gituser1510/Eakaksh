﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmaDBWebCrawlingWindowsService
{
    public static class DbContextExtension
    {
        // Extension method of DbContext object
        public static void ExecuteStoredProcedure(this DbContext @this, string storeProcName, params object[] parameters)
        {
            string command = "EXEC " + storeProcName + " @Paramtable";
            @this.Database.ExecuteSqlCommand(command, parameters);       
        }

        public static DataSet GetResultFromProcedure(this DbContext @this)
        {
            DataSet ds = null;

            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
            {
                cmd.CommandText = "Testing";
                cmd.Connection = (System.Data.SqlClient.SqlConnection)@this.Database.Connection;
                cmd.Parameters.AddWithValue("@CompanyID", 8953);
                cmd.CommandType = CommandType.StoredProcedure;
                
                System.Data.SqlClient.SqlDataAdapter adapter = new System.Data.SqlClient.SqlDataAdapter(cmd);

                ds = new DataSet();
                adapter.Fill(ds);              
            }
            return ds;
        }
    }
}
